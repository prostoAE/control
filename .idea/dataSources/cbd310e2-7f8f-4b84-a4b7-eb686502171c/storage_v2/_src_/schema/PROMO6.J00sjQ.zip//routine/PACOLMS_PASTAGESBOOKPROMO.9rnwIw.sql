create PROCEDURE pacolms_PaStagesBookPromo(p_array_size IN PLS_INTEGER DEFAULT 10000)
IS
TYPE ARRAY IS TABLE OF xPromoAction_Stage%ROWTYPE;
l_data ARRAY;

CURSOR c IS SELECT * FROM View_PaStagesBookPromo;

BEGIN
    OPEN c;
    LOOP
        FETCH c BULK COLLECT INTO l_data LIMIT p_array_size;
        FORALL i IN 1..l_data.COUNT
        INSERT INTO xPromoAction_Stage VALUES l_data(i);
        commit;
        EXIT WHEN c%NOTFOUND;
    END LOOP;
    CLOSE c;
    --delete from xPromoAction_Stage where stage_id = 2;
    commit;
END;
/

