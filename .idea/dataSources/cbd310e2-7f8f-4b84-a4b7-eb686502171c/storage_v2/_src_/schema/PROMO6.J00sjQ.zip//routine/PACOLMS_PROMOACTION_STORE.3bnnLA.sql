create PROCEDURE pacolms_PromoAction_store(p_array_size IN PLS_INTEGER DEFAULT 10000)
IS
TYPE ARRAY IS TABLE OF xPromoAction_Goods_Stores%ROWTYPE;
l_data         ARRAY;

--CURSOR c IS SELECT * FROM View_PromoAction_Store;
CURSOR c IS
select  /*+ DRIVING_SITE(rs) */
        rs.pid as pid,
        rs.ac as orderAcCode,
        rs.an as goodName,
        rs.baseprice as baseprice,
        to_char(rs.baseprice * (1 - (rs.dp / 100))) as buyPrice,
        to_char(rs.dp) as discount,
        rs.pcb as PCB,
        rs.flow_type as flowType,
        rs.stName as storeName,
        rs.stCode as storeCode,
        rs.reqQ as quantity,
        rs.transform_status as status,
        rs.logisticActivity as activity,
        rs.suNum as supplierCode,
        rs.suName as supplierName,
        rs.discount_start_date as discountStartDate,
        rs.discount_end_date as discountEndDate,
        rs.need_offer_comment as comments,
        rs.stage_id as stageId,
        rs.stage_name as stageName,
        rs.state as state,
        rs.npk as npk,
        rs.preQuantity
   from (select /*+ DRIVING_SITE(pa) */
                pa.id as pid,
                n.price,
                n.third,
                ns.quantity               as preQuantity,
                pa.book_promo_type        as bpt,
                pa.promo_place            as pp,
                ag.auchan_code            as ac,
                ag.name                   as an,
                disc.discount_percent     as dp,
                n.name                    as Nname,
                nog.baseprice             as baseprice,
                nog.discount_start_date   as discount_start_date,
                nog.discount_end_date     as discount_end_date,
                agrp.flow_type            as fType,
                agsu.pcb                  as pcb,
                st.name                   as stName,
                st.code                   as stCode,
                supp.supplier_number      as suNum,
                supp.name                 as suName,
                agrp.flow_type,
                naa.recalculated_quantity as reqQ,
                naa.transform_status,
                naa.logisticActivity,
                no.need_offer_comment,
                stag.id as stage_id,
                stag.name as stage_name,
                ps.stage_status_id as state, --1 ?? ???????, 2 ???????, 3 ????????
                nog.operation_code as npk
  from PACOLMS_PRD.PROMOACTION/*@sup*/ pa
---SEGMENT REMOVE---
 --inner join PACOLMS_PRD.SEGMENT/*@sup*/ s
 --   on (s.id = pa.segment_id)
---MARKET REMOVE---
 --inner join PACOLMS_PRD.MARKET/*@sup*/ m
 --   on (m.id = s.market_id and m.aid in (5,6))
---MARKET REMOVE---
 inner join PACOLMS_PRD.NEED/*@sup*/ n
    on (pa.id = n.promoaction_id)
 inner join PACOLMS_PRD.NEED_OFFER/*@sup*/ no
    on (n.id = no.need_id)
 inner join PACOLMS_PRD.NEED_OFFER_GOODS/*@sup*/ nog
    on (nog.need_offer_id = no.id)
  left join PACOLMS_PRD.NEED_OFFER_DISCOUNT/*@sup*/ disc
    on (disc.need_offer_id = no.id or disc.need_offer_goods_id = nog.id)
 inner join PACOLMS_PRD.AUCHAN_GOODS/*@sup*/ ag
    on (nog.auchan_code = ag.auchan_code)
 inner join PACOLMS_PRD.SUPPLIER/*@sup*/ supp
    on (nog.supplier_id = supp.id)
  --?.?. ????? ????? ???? ??? ?? ???????
  left join PACOLMS_PRD.NEED_ANSWER_GOODS/*@sup*/ nag
    on (nag.need_offer_goods_id = nog.id)
  left join PACOLMS_PRD.NEED_ANSWER_ANSWER/*@sup*/ naa
    on (naa.need_answer_goods_id = nag.id and naa.quantity > 0)
  left join PACOLMS_PRD.STORE/*@sup*/ st
    on (st.id = naa.store_id)
  left join PACOLMS_PRD.GRAPPE/*@sup*/ st_grp
    on (st_grp.target_store_id = st.id)
  left join PACOLMS_PRD.GRAPPE/*@sup*/ pr_str_grp
    on (st_grp.parent_id = pr_str_grp.id)
  left join PACOLMS_PRD.AGOODS_REGPROFILE/*@sup*/ agrp
    on (agrp.auchan_code = nog.auchan_code and
       (agrp.grappe_id = st_grp.id or agrp.grappe_id = pr_str_grp.id))
  left join PACOLMS_PRD.AGOODS_SUPPLYCHAIN/*@sup*/ agsu
    on (agsu.auchan_code = nog.auchan_code and
        agsu.supplier_id = nog.supplier_id and
       (agsu.grappe_id = st_grp.id or agsu.grappe_id = pr_str_grp.id))
  left join PACOLMS_PRD.NEED_STORE/*@sup*/ ns
    on (ns.store_id = st.id and ns.need_id = n.id)
 inner join PACOLMS_PRD.PROMOACTION_STAGE/*@sup*/ ps
    on (ps.promoaction_id = pa.id and ps.end_date > sysdate
                                  and ps.pa_stage_id = (SELECT p.pa_stage_id
                                                          FROM PACOLMS_PRD.PROMOACTION_STAGE/*@sup*/ p
                                                         WHERE p.promoaction_id = ps.promoaction_id
                                                           AND p.start_date = (SELECT min(t.start_date)
                                                                                 FROM PACOLMS_PRD.PROMOACTION_STAGE/*@sup*/ t
                                                                                WHERE t.end_date > sysdate
                                                                                  AND t.promoaction_id = p.promoaction_id)))
  inner join PACOLMS_PRD.PA_STAGE/*@sup*/ stag on (stag.id = ps.pa_stage_id)
  inner join PACOLMS_PRD.PROMOACTION_STATE/*@sup*/ pa_stat on (pa_stat.promoaction_id = ps.promoaction_id)
  inner join PACOLMS_PRD.PA_STATE/*@sup*/ stat on (stat.id = pa_stat.state_id and stat.id not in (3,5))
  where pa.promo_place is not null
    and st.code is not null
    --and no.id not in (2000653081498,2000653081492,2000653081474,2000653081468,2000653081480,2000659171919,2000659199159,
    --                  2000628441699,2000628441687,2000628441693,2000653081486,2000653083366,2000685606351)
    /*and nog.id not in (2000590318062,2000705434655,2000705434651,2000705428682,2000705427324,2000706679159,
                      2000706679153,2000706660889,2000706660877,2000715456217)*/
) rs;
--ORDER BY rs.pid;

BEGIN
    OPEN c;
    LOOP
      declare
        --UNIQUE_EXCEPTION EXCEPTION;
        --PRAGMA EXCEPTION_INIT(unique_exception, -00001);
        SAVE_EXCEPTION EXCEPTION;
        PRAGMA EXCEPTION_INIT(save_exception, -24381);
        errors         NUMBER;
        bad_stmt_no    PLS_INTEGER;
      begin
        FETCH c BULK COLLECT INTO l_data LIMIT p_array_size;
        FORALL i IN 1..l_data.COUNT SAVE EXCEPTIONS
        INSERT INTO xPromoAction_Goods_Stores VALUES l_data(i);
      exception
        WHEN SAVE_EXCEPTION THEN
           errors := SQL%BULK_EXCEPTIONS.COUNT;
              DBMS_OUTPUT.PUT_LINE('Number of statements that failed: ' || errors);
                 FOR i IN 1..errors LOOP
                       bad_stmt_no := SQL%BULK_EXCEPTIONS(i).ERROR_INDEX;
                       DBMS_OUTPUT.PUT_LINE(
                       SQLERRM(-SQL%BULK_EXCEPTIONS(i).ERROR_CODE)
                       ||', PID='||l_data(bad_stmt_no).pid
                       ||', AUCNAN_CODE='||l_data(bad_stmt_no).orderaccode
                       ||', STORE_CODE='||l_data(bad_stmt_no).storecode);
                 END LOOP;
        WHEN OTHERS THEN
          dbms_output.put_line('pacolms_PromoAction_store ERROR = '||SQLERRM);
        end;
      commit;
        EXIT WHEN c%NOTFOUND;
    END LOOP;
    CLOSE c;
END;
/

