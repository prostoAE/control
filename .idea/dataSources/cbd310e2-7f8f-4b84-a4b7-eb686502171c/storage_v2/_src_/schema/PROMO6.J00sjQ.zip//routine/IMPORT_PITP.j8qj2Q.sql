create PROCEDURE import_PITP IS
       seq_val  number;
BEGIN
  /*
  for x in(select * from xPitp t)
    loop
      seq_val := PA_SEQUENCE.NEXTVAL;
      --dbms_output.put_line(seq_val||' x.ORDERACCODE = '||x.ORDERACCODE);
      insert into PITP (ID, STORE_ID, START_DATE, END_DATE)
           VALUES(
                  seq_val, --ID
                  x.store_id,
                  x.start_date,
                  x.end_date
                 );
      update xPitp set import_id = seq_val where id = x.id;
      commit;
    end loop;
    */
    for x in(select id from store t)
    loop
          seq_val := PA_SEQUENCE.NEXTVAL;
          insert into PITP (ID, STORE_ID, START_DATE, END_DATE)
          VALUES(
                  seq_val, --ID
                  x.id,
                  sysdate,
                  sysdate+90
                 );
          commit;
    end loop;
END;
/

