create PROCEDURE import_PA_GOODS IS
       seq_val  number;
BEGIN
  for x in(select * from xPromoAction_Goods t)
    loop
      seq_val := PA_SEQUENCE.NEXTVAL;
      --dbms_output.put_line(seq_val||' x.ORDERACCODE = '||x.ORDERACCODE);
      declare
      begin
        insert into PROMOACTION_GOODS (ID,
                                       AUCHAN_GOODS_ID,
                                       PROMOACTION_ID,
                                       COMMENTS,
                                       BUYER_ID,
                                       START_DISCOUNT_DATE,
                                       END_DISCOUNT_DATE
                                       )

                                 VALUES(
                                 seq_val, --ID
                                 (SELECT id FROM AUCHAN_GOODS WHERE AUCHAN_CODE = x.ORDERACCODE), -- AUCHAN_GOODS_ID
                                 (SELECT import_new_id FROM xPromoAction WHERE pid = x.pid),      -- PROMOACTION_ID
                                 x.comments,          -- COMMENTS
                                 x.buyer_user_id,     -- BUYER_ID
                                 x.discountstartdate, -- START_DISCOUNT_DATE
                                 x.discountenddate    -- END_DISCOUNT_DATE
                                );
        update xPromoAction_Goods set import_new_id = seq_val where pid = x.pid and orderaccode = x.orderaccode;
      exception
        when OTHERS then
          dbms_output.put_line('x.pid = '||x.pid||' ERROR = '||SQLERRM);
      end;
        commit;
    end loop;

END;
/

