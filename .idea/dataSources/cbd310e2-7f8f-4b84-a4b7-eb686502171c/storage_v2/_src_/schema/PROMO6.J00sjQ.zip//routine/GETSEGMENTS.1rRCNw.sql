create function getSegments(p$template_id IN NUMBER)
return VARCHAR2
AS
 results VARCHAR2(4000);
 v_length NUMBER;
begin
   for x in (select se.aid/*||' '||se.name*/ segment
               from SEGMENT se, PA_TEMPLATE_SEGMENT tse
              where se.id = tse.segment_id
                and tse.pa_template_id = p$template_id)
   loop
     results := results||','||x.segment;
     --dbms_output.put_line('result: '||results);
   end loop;
   v_length := length(results);
   return substr(results, 2, v_length);
end;


/

