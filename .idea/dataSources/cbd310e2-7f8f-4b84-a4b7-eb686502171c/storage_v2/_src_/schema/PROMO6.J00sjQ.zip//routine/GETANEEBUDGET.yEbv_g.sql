create function getAneeBudget(p$pa_type IN VARCHAR2, p$segment IN NUMBER, p$supplier IN NUMBER)
return NUMBER
AS
  results NUMBER;
  v$year NUMBER;
begin
  select to_char(sysdate, 'YYYY')
    into v$year
    from dual;
  --dbms_output.put_line('p$pa_type = '||p$pa_type);
  --dbms_output.put_line('p$segment = '||p$segment);
  --dbms_output.put_line('p$supplier = '||p$supplier);
  begin
    select a.budget
    into results
    from (
    select max(agrs.billing_cost_per_service) as budget, max(agr.version) over(partition by su.cod_utl_supplier) as max_version, agr.version
    --agrs.id_company as storeType, su.cod_utl_supplier as supplierNumber, ncl.cod_utl_enc_usr as segmentAid, agrs.id_service_type as promoType, max(agrs.billing_cost_per_service) as budget
      from agreement@aneedb agr
      join agr_service@aneedb agrs on agrs.id_agreement = agr.id_agreement
      join agr_condition@aneedb agrc on agrc.id_agreement = agr.id_agreement
      join negotiation_group@aneedb ng on ng.id_negotiation_group = agrc.id_negotiation_group
       and ng.id_supplier = agrc.id_supplier
      join supplier@aneedb su on su.id_supplier = agr.id_supplier
      join ncl_element@aneedb ncl on ncl.id_element = ng.id_element
     where 1 = 1
       and agr.year = v$year --2018
       and agrs.id_service_type = p$pa_type --'PPSC'
       and ncl.cod_utl_enc_usr = p$segment --385 --?
       and su.cod_utl_supplier = ''||p$supplier||'' --'2354' --?
       and agr.ID_AGR_STATUS = 'SGN'
     group by agrs.id_company,
              su.cod_utl_supplier,
              ncl.cod_utl_enc_usr,
              agrs.id_service_type,
              agr.version
              ) a
     where a.version = a.max_version;
  exception when others then
    --dbms_output.put_line('SQLERRM = '||SQLERRM||' '||p$pa_type||' '||p$segment||' '||p$supplier);
    null;
    --dbms_output.put_line(p$supplier||'('||p$segment||','||p$pa_type||')');
  end;
  --dbms_output.put_line('results = '||results);
  --dbms_output.put_line('***************************************');
  return results;
end;
/*
declare
  results NUMBER;
  supplier VARCHAR2(30);
  pa_type VARCHAR2(30);
begin
  --supplier := '2354';
  --pa_type := 'TGSC';
  -- Call the function
   results := getaneebudget(p$pa_type => 'TGSC',
                           p$segment => 385,
                           p$supplier => '2354');
  dbms_output.put_line('results = '||results);
end;
*/
/

