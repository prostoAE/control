create view VIEW_PASTAGESBOOKPROMO as
select rs.pid             as pId,
       rs.stage_id        as stage_id,
       rs.stage_status_id as stage_status_id,
       rs.start_date      as start_date,
       rs.end_date        as end_date,
       rs.is_checked      as is_checked,
       '1'                as isBookPromo
   from (select /*+DRIVING_SITE(pa) */
                pa.id               as pid,
                ps2.pa_stage_id     as stage_id,
                ps2.stage_status_id as stage_status_id,
                ps2.start_date      as start_date,
                ps2.end_date        as end_date,
                ps2.is_checked      as is_checked
  from PACOLMS_PRD.PROMOACTION/*@sup*/ pa
---SEGMENT REMOVE---
 --inner join PACOLMS_PRD.SEGMENT/*@sup*/ s
 --   on (s.id = pa.segment_id)
---MARKET REMOVE---
 --inner join PACOLMS_PRD.MARKET/*@sup*/ m
 --   on (m.id = s.market_id and m.aid in (5,6))
---MARKET REMOVE---
 inner join PACOLMS_PRD.NEED/*@sup*/ n
    on (pa.id = n.promoaction_id)
  left join PACOLMS_PRD.NEED_ANSWER/*@sup*/ na
    on(na.need_id = n.id)

 inner join PACOLMS_PRD.PROMOACTION_STAGE/*@sup*/ ps
    on (ps.promoaction_id = pa.id and ps.end_date > sysdate --to_date('12.01.2015','dd.mm.yyyy')
                                  and ps.pa_stage_id = (SELECT max(p.pa_stage_id)
                                                          FROM PACOLMS_PRD.PROMOACTION_STAGE/*@sup*/ p
                                                         WHERE p.promoaction_id = ps.promoaction_id))
  inner join PACOLMS_PRD.PROMOACTION_STAGE/*@sup*/ ps2 on (ps2.promoaction_id = ps.promoaction_id)
  inner join PACOLMS_PRD.PROMOACTION_STATE/*@sup*/ pa_stat on (pa_stat.promoaction_id = ps.promoaction_id)
  inner join PACOLMS_PRD.PA_STATE/*@sup*/ stat on (stat.id = pa_stat.state_id and stat.id not in (3,5))
 where na.id is not null and pa.book_promo_type is not null
) rs
order by rs.pid, rs.stage_id
/

