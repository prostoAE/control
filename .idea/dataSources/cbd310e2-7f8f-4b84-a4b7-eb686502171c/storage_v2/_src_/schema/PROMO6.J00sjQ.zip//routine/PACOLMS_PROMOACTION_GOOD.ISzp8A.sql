create PROCEDURE pacolms_PromoAction_good(p_array_size IN PLS_INTEGER DEFAULT 10000)
IS
TYPE ARRAY IS TABLE OF xPromoAction_Goods%ROWTYPE;
l_data ARRAY;

CURSOR c IS SELECT * FROM View_PromoAction_Good;

BEGIN
    OPEN c;
    LOOP
        FETCH c BULK COLLECT INTO l_data LIMIT p_array_size;
        FORALL i IN 1..l_data.COUNT
        INSERT INTO xPromoAction_Goods VALUES l_data(i);
        commit;
        EXIT WHEN c%NOTFOUND;
    END LOOP;
    CLOSE c;
END;
/

