create PROCEDURE pacolms_PaStagesPromoAction(p_array_size IN PLS_INTEGER DEFAULT 10000)
IS
TYPE ARRAY IS TABLE OF xPromoAction_Stage%ROWTYPE;
l_data ARRAY;

CURSOR c IS SELECT * FROM View_PaStagesPromoAction;

BEGIN
    OPEN c;
    LOOP
        FETCH c BULK COLLECT INTO l_data LIMIT p_array_size;
        FORALL i IN 1..l_data.COUNT
        INSERT INTO xPromoAction_Stage VALUES l_data(i);
        commit;
        EXIT WHEN c%NOTFOUND;
    END LOOP;
    CLOSE c;
    --delete from xPromoAction_Stage where stage_id = 2;
    commit;
    --???????? PA ? ??????. ?????????:
    --delete from xPromoAction_Stage where pid = 2000679699796;
    --commit;
    begin
      --7266 (7054)
      for a in (select distinct t.pid, t.stage_status_id, t.end_date, t.is_checked, Isbookpromo
                  from xPromoAction_Stage t
                  where t.stage_id = 1
                  --and pid = 100012445727
                  order by t.pid )
      loop
        insert into xPromoAction_Stage(Pid, Stage_Id, Stage_Status_Id, Start_Date, End_Date, Is_Checked, Isbookpromo)
                                values(a.pid, 2, (case when sysdate < a.end_date-6 then 1
                                                       when sysdate >= a.end_date-6 and sysdate <= a.end_date then 2
                                                       when sysdate > a.end_date then 3 end), a.end_date-6, a.end_date, a.is_checked, a.isbookpromo );
        update xPromoAction_Stage b
           set b.end_date = b.end_date - 7
         where b.pid = a.pid and b.stage_id = 1;
        commit;
      end loop;
    end;
END;
/

