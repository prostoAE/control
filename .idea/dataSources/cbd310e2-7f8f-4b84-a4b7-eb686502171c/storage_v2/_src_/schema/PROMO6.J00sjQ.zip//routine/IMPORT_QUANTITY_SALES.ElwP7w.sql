create procedure import_quantity_sales
is
  v$count NUMBER := 0;
  v_ts1 TIMESTAMP;
  v_ts2 TIMESTAMP;
  v_diff INTERVAL DAY TO SECOND;
  v_diff_ms NUMBER;
begin/*
  execute immediate 'truncate table quantity_sales';
  v_ts1 := systimestamp;
  for a in (select distinct(s.code) store_Code, pas.start_date - 15 start_Date
              from promoaction_goods_stores pags, promoaction_goods pag, auchan_goods ag, promoaction_stage pas,
                   stage_type st, store s
             where pag.id = pags.promoaction_goods_id
               and ag.id = pag.auchan_goods_id
               and pas.promoaction_id = pag.promoaction_id
               and sysdate between pas.start_date and pas.end_date
               and st.id = pas.stage_type_id
               and s.id = pags.store_id
               and st.code = 'CONFIRM_QUANTITY'
             order by s.code)
  loop
    dbms_output.put_line('********************************************************************');
    dbms_output.put_line('store_code = '||a.store_code);
    declare
      v$sum      NUMBER := 0;
    begin
      for b in (select sum(ca.qtunca) qtunca_sum,
                       ca.NARTCA NARTCA,
                       ca.CIDICA
                  from wwhh.cawhtb@dwh ca
                 where ca.DDVACA between a.start_Date and sysdate -- 2 недели от начала этапа
                   and ca.prnoca = 'N'
                   and ca.gemaca = 'G'
                   and ca.nartca <> 999999999
                   and ca.csecca <> '18'
                   and ca.CIDICA = a.store_Code
                 group by ca.NARTCA, ca.CIDICA
                having sum(ca.qtunca) > -1)
        loop
          declare
            v$storeId       NUMBER;
            v$auchanGoodsId NUMBER;
          begin
            select id into v$auchanGoodsId from auchan_goods where auchan_code = b.NARTCA;
            select id into v$storeId from store where code = b.cidica;
            insert into quantity_sales values(v$auchanGoodsId, v$storeId, b.NARTCA, b.CIDICA, b.qtunca_sum, systimestamp);
          exception
            when others then
              dbms_output.put_line('ERROR insert = '||SQLERRM);
          end;
          if (v$count > 0 and mod(v$count, 10000) = 0) then
            dbms_output.put_line('count = '||v$count);
            commit;
          end if;
          v$count := v$count + 1;
        end loop;
    end;
  end loop;
  v_ts2 := systimestamp;
  commit;
  dbms_output.put_line('*****************************');
  dbms_output.put_line ( 'TS1 : ' || To_Char(v_ts1,'hh24:mi:ss ff6') ||  ' / TS2: ' || To_Char(v_ts2,'hh24:mi:ss ff6') );
  v_diff := v_ts2 - v_ts1;
  dbms_output.put_line ( 'Difference as Interval : ' || v_diff );
  v_diff_ms := ( extract(hour from v_diff)   * 3600 +
                 extract(minute from v_diff) * 60   +
                 extract(second from v_diff) )
               * 1000;
  dbms_output.put_line ( 'Difference as MS       : ' || v_diff_ms );
  declare
    v$countRows number := 0;
  begin
    select count(*) into v$countRows from quantity_sales;
    dbms_output.put_line ( 'inserted rows          : ' ||v$countRows );
    dbms_output.put_line ( 'average ms for 1 row   : ' || v_diff_ms/v$countRows);
  end;
  */
  null;
end;
/

