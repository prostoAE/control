create PROCEDURE import_PLACE IS
       seq_val  number;
BEGIN
  for x in(select t.*, (select code from PACOLMS_PRD.store/*@sup*/ where id = t.store_id) storeCode
             from PACOLMS_PRD.tg/*@sup*/ t
            where t.is_active = 1
              and t.name not like '%P%' and length(t.name) > 3)
    loop
      seq_val := PA_SEQUENCE.NEXTVAL;
      --dbms_output.put_line(seq_val||' x.ORDERACCODE = '||x.ORDERACCODE);
      begin
        insert into PLACE (ID, NAME, STORE_ID, PLACE_TYPE_ID, IS_DELETED, CREATE_DATE, TLV)
             VALUES(
                    seq_val, --ID
                    x.name,
                    (select id from store where code = x.storeCode),
                    (select id from place_type pt where pt.name = 'TG'),
                    0,
                    x.create_date,
                    null
                    );
        commit;
      exception when others then
        dbms_output.put_line('ERROR FOR TG PLACE = '||x.name||' '||SQLERRM);
      end;
    end loop;

    for x in(select t.*, (select code
                            from PACOLMS_PRD.store/*@sup*/
                           where id = t.store_id) storeCode
               from PACOLMS_PRD.ponton/*@sup*/ t
              where t.is_active = 1
                and length(t.name) > 5)
    loop
      begin
        seq_val := PA_SEQUENCE.NEXTVAL;
        --dbms_output.put_line(seq_val||' x.ORDERACCODE = '||x.ORDERACCODE);
        insert into PLACE (ID, NAME, STORE_ID, PLACE_TYPE_ID, IS_DELETED, CREATE_DATE, TLV)
             VALUES(
                    seq_val, --ID
                    x.name,
                    (select id from store where code = x.storeCode),
                    (select id from place_type pt where pt.name = 'Ponton'),
                    0,
                    x.create_date,
                    null
                    );
        commit;
      exception when others then
        dbms_output.put_line('ERROR FOR PONTON PLACE = '||x.name||' '||SQLERRM);
      end;
    end loop;

END;
/

