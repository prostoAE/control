create PROCEDURE import_ROLES IS
  admin_role_id NUMBER;
BEGIN

  for x in(SELECT * FROM PACOLMS_PRD.USER_ROLE/*@sup*/)
  loop
    begin
      insert into ROLES
           VALUES(x.id,
                  x.name,
                    null
                    );
       commit;
     exception when others then
        dbms_output.put_line('ROLES SQLERRM = '||SQLERRM);
     end;
   end loop;

  select id
    into admin_role_id
    from ROLES
   where name = 'Administrator';

   update ROLES
      set tlv = 'stores_11roles__11control0templat11contCoz0addedPA0pitp___11places_10admin__11users__11tec____0setting0deletPA0edit_Pa0change_11order__10codif__0editTyp11confirm0scanner0deletGD0addedGD0'
    where id = admin_role_id;
   commit;



   for x in (SELECT id FROM MENU WHERE id <> 0 order by id)
   loop
      insert into ROLE_MENU values(admin_role_id, x.id);
      commit;
   end loop;

   for x in(select * from PACOLMS_PRD.USER_USER_ROLE/*@sup*/ uur, PACOLMS_PRD.system_user/*@sup*/ su
             where uur.user_id = su.id
               and su.is_colms = 0)
   loop
     begin
       insert into USER_AUTHORITY
             VALUES(
                     x.user_id,
                     x.user_role_id
                    );
       commit;
     exception when others then
        dbms_output.put_line('USER_AUTHORITY SQLERRM = '||SQLERRM);
     end;
   end loop;

END;
/

