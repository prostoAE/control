create PROCEDURE import_PA_STAGES IS
       seq_val  number;
BEGIN
  for x in(select * from xPromoaction_Stage t order by t.pid, t.stage_id)
    loop
      seq_val := PA_SEQUENCE.NEXTVAL;
      --dbms_output.put_line(seq_val||' x.pid = '||x.pid);
      begin
        insert into PROMOACTION_STAGE (ID,
                                       PROMOACTION_ID,
                                       STAGE_STATUS_ID,
                                       IS_CHECKED,
                                       START_DATE,
                                       END_DATE,
                                       UPDATE_TIME,
                                       STAGE_POSITION,
                                       STAGE_TYPE_ID,
                                       RM_TEMPLATE_STAGE_ID,
                                       ADDITION_FUNCTION,
                                       IS_ACTIVE
                                       )

                                 VALUES(
                                 seq_val, --ID
                                 (SELECT import_new_id FROM xPromoAction WHERE pid = x.pid),   --PROMOACTION_ID
                                 1,--x.STAGE_STATUS_ID, --STAGE_STATUS_ID
                                 0, --x.IS_CHECKED,      --IS_CHECKED
                                 x.START_DATE,      --START_DATE
                                 x.END_DATE,        --END_DATE
                                 SYSDATE,           --UPDATE_TIME
                                 (case when x.stage_id = 1 then 1
                                        when x.stage_id = 2 then 2
                                         when x.stage_id = 3 then 3
                                          when x.stage_id = 4 then 4
                                           when x.stage_id = 5 then 5
                                            when x.stage_id = 6 then 6
                                             when x.stage_id = 7 then 7
                                   end
                                 ),   --STAGE_POSITION
                                 (SELECT id
                                    FROM STAGE_TYPE
                                   WHERE code = case when x.stage_id = 1 then 'DEF_PROMO'
                                                      when x.stage_id = 2 then 'PRE_QUANTITY'
                                                       when x.stage_id = 3 then 'COZ_ANSWER'
                                                        when x.stage_id = 4 then 'CONFIRM_QUANTITY'
                                                         when x.stage_id = 5 then 'CODIFICATION'
                                                          when x.stage_id = 6 then 'ORDER'
                                                           when x.stage_id = 7 then 'MOUNT'
                                                end
                                  ),    --STAGE_TYPE_ID
                                  NULL, --RM_TEMPLATE_STAGE_ID
                                  (CASE WHEN x.stage_id = 7 AND x.isBookPromo = 1 then 'AUTOMOUNT_TRG' else null end), --ADDITION_FUNCTION
                                  1     --IS_ACTIVE
                               );

        if (x.stage_id = 7) then
          insert into PROMOACTION_STAGE (ID,
                                         PROMOACTION_ID,
                                         STAGE_STATUS_ID,
                                         IS_CHECKED,
                                         START_DATE,
                                         END_DATE,
                                         UPDATE_TIME,
                                         STAGE_POSITION,
                                         STAGE_TYPE_ID,
                                         RM_TEMPLATE_STAGE_ID,
                                         ADDITION_FUNCTION,
                                         IS_ACTIVE
                                        )

                                    VALUES(PA_SEQUENCE.NEXTVAL,
                                           (SELECT import_new_id FROM xPromoAction WHERE pid = x.pid),   --PROMOACTION_ID
                                            1, --x.STAGE_STATUS_ID, --STAGE_STATUS_ID
                                            0, --x.IS_CHECKED,      --IS_CHECKED
                                            x.END_DATE+1,      --START_DATE
                                            x.END_DATE+1,      --END_DATE
                                            SYSDATE,           --UPDATE_TIME
                                            7,                 --STAGE_POSITION
                                            (SELECT id FROM STAGE_TYPE WHERE code = 'BUDGET'),    --STAGE_TYPE_ID
                                            NULL, --RM_TEMPLATE_STAGE_ID
                                            NULL, --ADDITION_FUNCTION
                                            1     --IS_ACTIVE
                                    );
        end if;
      exception when others then
        dbms_output.put_line(' x.pid = '||x.pid||' '||SQLERRM);
      end;
      commit;
    end loop;
END;
/

