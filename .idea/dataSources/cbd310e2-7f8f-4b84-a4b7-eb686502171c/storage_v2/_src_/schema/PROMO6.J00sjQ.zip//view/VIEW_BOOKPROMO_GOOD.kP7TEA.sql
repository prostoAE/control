create view VIEW_BOOKPROMO_GOOD as
select rs.pid as pid,
        rs.ac as orderAcCode,
        rs.an as goodName,
        rs.discount_start_date as discountStartDate,
        rs.discount_end_date as discountEndDate,
        rs.need_offer_comment as comments,
        rs.buyer_user_id as buyer_user_id,
        rs.stage_id as stageId,
        rs.stage_name as stageName,
        rs.state as state,
        rs.npk as npk,
        0 as import_new_id,
        rs.basePrice,
        rs.discount,
        rs.supplier_id,
        rs.budget
   from (select /*+DRIVING_SITE(pa) */
                pa.id as pid,
                ag.auchan_code            as ac,
                ag.name                   as an,
                nog.discount_start_date   as discount_start_date,
                nog.discount_end_date     as discount_end_date,
                no.need_offer_comment,
                nog.buyer_user_id as buyer_user_id,
                stag.id as stage_id,
                stag.name as stage_name,
                ps.stage_status_id as state, --1 ?? ???????, 2 ???????, 3 ????????
                nog.operation_code as npk,
                nog.baseprice as basePrice,
                disc.discount_percent as discount,
                (select s.id from supplier s where s.code = (select su.supplier_number from PACOLMS_PRD.supplier su where su.id = nog.supplier_id)) as supplier_id,
                nob.budget
  from PACOLMS_PRD.PROMOACTION/*@sup*/ pa
---SEGMENT REMOVE---
 --inner join PACOLMS_PRD.SEGMENT/*@sup*/ s
 --   on (s.id = pa.segment_id)
---MARKET REMOVE---
 --inner join PACOLMS_PRD.MARKET/*@sup*/ m
 --   on (m.id = s.market_id and m.aid in (5,6))
---MARKET REMOVE---
  left outer join PACOLMS_PRD.PERIOD_CALENDAR/*@sup*/ pc
    on (pa.promo_period = pc.id)
 inner join PACOLMS_PRD.NEED/*@sup*/ n
    on (pa.id = n.promoaction_id)
  left join PACOLMS_PRD.NEED_OFFER/*@sup*/ no
    on (n.id = no.need_id)
 inner join PACOLMS_PRD.NEED_OFFER_GOODS/*@sup*/ nog
    on (nog.need_offer_id = no.id and nog.supplier_id = (select max(t.supplier_id) from PACOLMS_PRD.NEED_OFFER_GOODS/*@sup*/ t where t.need_offer_id = no.id and t.auchan_code = nog.auchan_code))
  left join PACOLMS_PRD.NEED_OFFER_DISCOUNT/*@sup*/ disc
    on (disc.need_offer_id = no.id or disc.need_offer_goods_id = nog.id)
 inner join PACOLMS_PRD.AUCHAN_GOODS/*@sup*/ ag
    on (nog.auchan_code = ag.auchan_code)
 --?.?. ??? BookPromo ????? ?????? ???? ??????????? ???????
 inner join PACOLMS_PRD.NEED_ANSWER_GOODS nag
    on (nag.need_offer_goods_id = nog.id)
  left join PACOLMS_PRD.NEED_OFFER_BUDGET nob
    on (no.id = nob.need_offer_id)
 inner join PACOLMS_PRD.PROMOACTION_STAGE ps
    on (ps.promoaction_id = pa.id and ps.end_date > sysdate-7
                                  and ps.pa_stage_id = (SELECT p.pa_stage_id
                                                          FROM PACOLMS_PRD.PROMOACTION_STAGE p
                                                         WHERE p.promoaction_id = ps.promoaction_id
                                                           AND p.start_date = (SELECT min(t.start_date)
                                                                                 FROM PACOLMS_PRD.PROMOACTION_STAGE t
                                                                                WHERE t.end_date > sysdate-7
                                                                                  AND t.promoaction_id = p.promoaction_id)))
  inner join PACOLMS_PRD.PA_STAGE/*@sup*/ stag on (stag.id = ps.pa_stage_id)
  inner join PACOLMS_PRD.PROMOACTION_STATE/*@sup*/ pa_stat on (pa_stat.promoaction_id = ps.promoaction_id)
  inner join PACOLMS_PRD.PA_STATE/*@sup*/ stat on (stat.id = pa_stat.state_id and stat.id not in (3,5))

 where pa.book_promo_type is not null
   --and no.id not in (2000674951709)
   -- NOG ID ?? ????? ?????, ?.?. ????? ??????? NOG ID ??????????????? max id ??????????
   --and nog.id not in (2000660187151,2000636327377,2000659041782,2000659041784,2000659042208,2000659042209,2000659042210,2000636327213,2000659042431,2000659199610,2000660186538)
) rs
/

