create PROCEDURE pacolms_promoAction_pa(p_array_size IN PLS_INTEGER DEFAULT 10000)
IS
TYPE ARRAY IS TABLE OF xPromoAction%ROWTYPE;
l_data ARRAY;

CURSOR c IS SELECT * FROM View_PromoAction_Pa;

BEGIN
    OPEN c;
    LOOP
        FETCH c BULK COLLECT INTO l_data LIMIT p_array_size;
        FORALL i IN 1..l_data.COUNT
        INSERT INTO xPromoAction VALUES l_data(i);
        commit;
        EXIT WHEN c%NOTFOUND;
    END LOOP;
    CLOSE c;
    for x in (select pid from xPromoAction
               where paEndDate - paStartDate > 14)
    loop
      delete from xPromoAction where pid = x.pid;
      commit;
      dbms_output.put_line('??????? ?? ??????? xPromoAction pid = '||x.pid);
    end loop;
END;
/

