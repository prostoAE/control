create PROCEDURE import_PA IS
  seq_val  number;
BEGIN
  for x in(select * from xPromoAction t order by t.paEndDate)
    loop
      begin
        seq_val := PA_SEQUENCE.NEXTVAL;
        insert into PROMOACTION (ID,
                                 NAME,
                                 PA_TEMPLATE_ID,
                                 PERIOD_CALENDAR_ID,
                                 SEGMENT_ID,
                                 PA_TYPE_ID,
                                 PLANNED_PRICE,
                                 THIRD,
                                 IS_DELETED,
                                 IS_CANCELED,
                                 IS_BROKEN,
                                 COMMENTS,
                                 CONTEXT_ID,
                                 CREATED_USER_ID,
                                 TEMPLATE_VERSION,
                                 NPK_CODE,CREATE_DATE, IS_PRICEFALL/*, DELETED_USER_ID, DELETE_DATE*/)

                                 VALUES(
                                 seq_val, --ID
                                 x.needname, --NAME
                                 99999999,   --PA_TEMPLATE_ID
                                 (SELECT pc.ID
                                    FROM PERIOD_CALENDAR pc
                                   WHERE trunc(pc.start_date) = trunc(x.pastartdate)
                                     AND trunc(pc.end_date) = trunc(x.paenddate)
                                     /*AND pt.name = case when x.promo_period is not null then '??????' else '??????' end*/), --PERIOD_CALENDAR_ID,
                                 (SELECT s.ID FROM SEGMENT s WHERE s.aid = x.segment), --SEGMENT_ID,
                                  case
                                    when x.promotype = '1' then (SELECT pt.id FROM PA_TYPE pt WHERE pt.code = 'Alt')
                                    when x.promotype = 'TG' then (SELECT pt.id FROM PA_TYPE pt WHERE pt.code = 'TG')
                                    when x.promotype = 'Ponton' then (SELECT pt.id FROM PA_TYPE pt WHERE pt.code = 'Ponton')
                                  end,       --PA_TYPE_ID,
                                  x.nPrice,  --PLANNED_PRICE,
                                  case
                                    when x.third = 'ONE' THEN 1
                                    when x.third = 'TWO' THEN 2
                                    when x.third = 'THREE' THEN 3
                                      else null
                                  end,       --THIRD,
                                  0,         --IS_DELETED,
                                  0,         --IS_CANCELED,
                                  0,         --IS_BROKEN,
                                  NULL,      --COMMENTS,
                                  NULL,      --CONTEXT_ID,
                                  x.user_id, --CREATED_USER_ID,
                                  NULL,      --TEMPLATE_VERSION,
                                  case when x.npk = 1 then 1 else null end, --NPK_CODE
                                  SYSDATE,
                                  0
                 );
        --dbms_output.put_line('x.pid = ' + x.pid);
        update xPromoAction set import_new_id = seq_val where pid = x.pid;
        commit;
      exception when others then
        dbms_output.put_line('SQLERRM = '||SQLERRM||', pa id = '||x.pid||', x.pastartdate = '||x.pastartdate||', x.paenddate = '||x.paenddate||', x.user_id = '||x.user_id);
      end;
    end loop;

END;
/

