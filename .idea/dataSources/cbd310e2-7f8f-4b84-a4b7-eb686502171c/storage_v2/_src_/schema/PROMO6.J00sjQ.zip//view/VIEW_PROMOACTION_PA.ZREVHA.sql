create view VIEW_PROMOACTION_PA as
select rs.pid as pId,
        case
          when rs.bpt is not null then
           to_char(rs.bpt) --'Book-Promo'
          when rs.pp is not null then
           (case rs.pp
             when 0 then
              'Ponton'
             else
              'TG'
           end)
        end as promoType,
        rs.sAid as segment,
        rs.nName as needName,
        rs.start_date as paStartDate,
        rs.end_date as paEndDate,
        nvl(rs.price, 0) nPrice,
        nvl(rs.third, '---') third,
        rs.npk as npk,
        rs.user_id as user_id,
        rs.promo_period as promo_period,
        0 as import_new_id
   from (select /*+DRIVING_SITE(pa) */
                pa.id as pid,
                pa.start_date,
                pa.end_date,
                n.price,
                n.third,
                pa.book_promo_type        as bpt,
                pa.promo_place            as pp,
                s.aid                     as sAid,
                n.name                    as Nname,
                --nog.operation_code as npk,
                na.is_operation as npk,
                pu.user_id as user_id,
                pa.promo_period as promo_period
  from PACOLMS_PRD.PROMOACTION/*@sup*/ pa
  left outer join PACOLMS_PRD.PERIOD_CALENDAR/*@sup*/ pc
    on (pa.promo_period = pc.id)
 inner join PACOLMS_PRD.SEGMENT/*@sup*/ s
    on (s.id = pa.segment_id)
---MARKET REMOVE---
 --inner join PACOLMS_PRD.MARKET/*@sup*/ m
 --   on (m.id = s.market_id and m.aid in (5,6))
---MARKET REMOVE---
 inner join PACOLMS_PRD.NEED/*@sup*/ n
    on (pa.id = n.promoaction_id)
 left join PACOLMS_PRD.NEED_ANSWER/*@sup*/ na
    on(na.need_id = n.id)
 inner join PACOLMS_PRD.PROMOACTION_STAGE/*@sup*/ ps
    on (ps.promoaction_id = pa.id and ps.end_date > sysdate --to_date('12.01.2015')
                                  and ps.pa_stage_id = (SELECT max(p.pa_stage_id)
                                                          FROM PACOLMS_PRD.PROMOACTION_STAGE/*@sup*/ p
                                                         WHERE p.promoaction_id = ps.promoaction_id))
  inner join PACOLMS_PRD.PROMOACTION_STATE/*@sup*/ pa_stat on (pa_stat.promoaction_id = ps.promoaction_id)
  inner join PACOLMS_PRD.PA_STATE/*@sup*/ stat on (stat.id = pa_stat.state_id and stat.id not in (3,5))
  inner join PACOLMS_PRD.PROMOACTION_USER/*@sup*/ pu on (pu.promoaction_id = pa.id)
 where pa.promo_place is not null
) rs
/

