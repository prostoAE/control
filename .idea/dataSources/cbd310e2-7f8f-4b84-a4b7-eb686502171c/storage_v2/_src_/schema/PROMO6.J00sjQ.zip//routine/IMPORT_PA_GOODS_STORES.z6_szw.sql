create PROCEDURE import_PA_GOODS_STORES IS
  seq_val  number;
  cnt      number := 0;
BEGIN
  for x in(select * from xPromoAction_Goods_Stores t order by t.pid, t.orderAcCode, t.storeCode)
    loop
      cnt := cnt + 1;
      seq_val := PA_SEQUENCE.NEXTVAL;
      begin
        insert into PROMOACTION_GOODS_STORES(
                ID,
                PROMOACTION_GOODS_ID,
                STORE_ID,
                STORE_ACTIVE,
                TARIFF,
                BASE_PRICE,
                DISCOUNT,
                BUDGET,
                SUPPLIER_ID,
                QUANTITY,
                RECALC_QUANTITY,
                PCB,
                AUTO_UPDATE_TIME,
                MANUAL_UPDATE_TIME,
                IS_CODIFIED,
                BUY_PRICE,
                FLOW_TYPE,
                ORDER_WAY,
                LOGISTIC_ACTIVITY_ID,
                PROMOACTION_GOODS_ORDER_ID,
                CONTROL_FACT_ID,
                IS_TEC_SUCCESS,
                CONFIRMATION_USER_ID,
                BUYER_USER_ID,
                IS_SAVE_ALL,
                IS_ASSORTIMENT
        )
        VALUES(seq_val, --ID
               (SELECT t.import_new_id FROM xPromoAction_Goods t WHERE t.pid = x.pid AND t.orderaccode = x.orderaccode), --PROMOACTION_GOODS_ID
               (SELECT id FROM STORE WHERE CODE = x.storeCode), --STORE_ID
               1,           --STORE_ACTIVE
               0,           --TARIFF,
               x.basePrice, --BASE_PRICE
               x.discount,  --DISCOUNT
               0,           --BUDGET
               (SELECT id FROM SUPPLIER WHERE CODE = x.supplierCode), --SUPPLIER_ID
               x.quantity,  --QUANTITY
               x.quantity,  --RECALC_QUANTITY,
               x.pcb,       --PCB,
               NULL,        --AUTO_UPDATE_TIME,
               NULL,        --MANUAL_UPDATE_TIME,
               (case when x.stageid > 4 then 1 else NULL end),--IS_CODIFIED,
               x.buyprice,  --BUY_PRICE,
              (case when x.flowtype = 1 then 'ST' when x.flowtype = 2 then 'TR' else NULL end), --FLOW_TYPE,
               NULL,        --ORDER_WAY,
               NULL,        --LOGISTIC_ACTIVITY_ID,
               NULL,        --PROMOACTION_GOODS_ORDER_ID,
               NULL,        --CONTROL_FACT_ID,
               NULL,        --IS_TEC_SUCCESS,
               NULL,        --CONFIRMATION_USER_ID,
               (SELECT t.buyer_user_id FROM xPromoAction_Goods t WHERE t.pid = x.pid AND t.orderaccode = x.orderaccode),        --BUYER_USER_ID,
               0,            --IS_SAVE_ALL
               (case when x.stageid > 4 then 1 else 0 end) --IS_ASSORTIMENT
        );
        if (x.pre_quantity > 0) then
          insert into PA_PRE_QUANTITY(id, PROMOACTION_ID, STORE_ID, QUANTITY, CREATED_DATE, CREATED_USER_ID) values(seq_val, (SELECT t.import_new_id FROM xPromoAction t WHERE t.pid = x.pid), (SELECT id FROM STORE WHERE CODE = x.storeCode), x.pre_quantity, SYSDATE,(SELECT t.buyer_user_id FROM xPromoAction_Goods t WHERE t.pid = x.pid AND t.orderaccode = x.orderaccode));
        end if;
      exception
        when OTHERS then
          dbms_output.put_line('x.pid = '||x.pid||' ERROR = '||SQLERRM);
      end;
      if (mod(cnt,10000)=0) then
         commit;
      end if;
    end loop;
    commit;
END;
/

