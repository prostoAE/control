create PROCEDURE import_PITP_PLACE(p$storeId NUMBER, p$newStoreId NUMBER) IS
       seq_val  number;
BEGIN
  /* PITP_TG */
  for x in(select st.id storeId, tg.name placeName, s.aid
             from pacolms_prd.PITP/*@sup*/ p, pacolms_prd.PITP_TG/*@sup*/ ptg, pacolms_prd.PERIOD_CALENDAR/*@sup*/ pc, pacolms_prd.SEGMENT/*@sup*/ s, pacolms_prd.TG/*@sup*/ tg, pacolms_prd.STORE/*@sup*/ st
            where p.id = ptg.pitp_id
              and p.promo_period = pc.id(+)
              and s.id = ptg.segment_id
              and tg.id = ptg.tg_id
              and st.id = p.storage_id
              and tg.is_active = 1
              and st.id = p$storeId
              and tg.name not like '%P%' and length(tg.name) > 3
              and ((p.year in (2016) and week = (select pca.period_number
                                                   from PERIOD_CALENDAR pca
                                                  where pca.period_type_id = 13074338
                                                    and sysdate between pca.start_date and pca.end_date+1))
                   or sysdate between pc.start_date and pc.end_date)
            order by p.storage_id, ptg.segment_id)
    loop
      seq_val := PA_SEQUENCE.NEXTVAL;
      begin
        dbms_output.put_line(' 1 x.placeName = '||x.placeName);
        insert into PITP_PLACE (ID, PITP_ID, PLACE_ID, SEGMENT_ID)
             VALUES(
                    seq_val, --ID
                    (select id from pitp where store_id = p$newStoreId and sysdate between start_date and end_date), --PITP_ID
                    (select id from place ps where name = x.placeName and ps.store_id = p$newStoreId), --PLACE_ID
                    (select id from segment where aid = x.aid) --SEGMENT_ID
                    );
        dbms_output.put_line(' PITP_TG x.storeId = '||x.storeId);
      exception
        when OTHERS then
          dbms_output.put_line('import_PITP_PLACE(PITP_TG) storeId = '||x.storeId||' placeName = '||x.placeName||' SEGMENT AID = '||x.aid||' ERROR = '||SQLERRM);
      end;
      --commit;
    end loop;

    /* PITP_PONTON */

  for x in(select st.id storeId, pnt.name placeName, s.aid
             from pacolms_prd.PITP/*@sup*/ p, pacolms_prd.PITP_PONTON/*@sup*/ pt, pacolms_prd.PERIOD_CALENDAR/*@sup*/ pc, pacolms_prd.SEGMENT/*@sup*/ s, pacolms_prd.PONTON/*@sup*/ pnt, pacolms_prd.STORE/*@sup*/ st
            where p.id = pt.pitp_id
              and p.promo_period = pc.id(+)
              and s.id = pt.segment_id
              and pnt.id = pt.ponton_id
              and st.id = p.storage_id
              and length(pnt.name) > 5
              and pnt.is_active = 1
              and st.id = p$storeId
              and ((p.year in (2016) and week = (select pca.period_number
                                                   from PERIOD_CALENDAR pca
                                                  where pca.period_type_id = 13074338
                                                    and sysdate between pca.start_date and pca.end_date+1))
                   or sysdate between pc.start_date and pc.end_date)
            order by p.storage_id, pt.segment_id)
    loop
      seq_val := PA_SEQUENCE.NEXTVAL;
      begin
        dbms_output.put_line(' 2 x.placeName = '||x.placeName);
        insert into PITP_PLACE(ID, PITP_ID, PLACE_ID, SEGMENT_ID)
             VALUES(
                    seq_val, --ID
                    (select id from pitp where store_id = p$newStoreId and sysdate between start_date and end_date), --PITP_ID
                    (select id from place ps where name = x.placeName and ps.store_id = p$newStoreId), --PLACE_ID
                    (select id from segment where aid = x.aid) --SEGMENT_ID
                    );
        dbms_output.put_line(' PITP_PONTON x.storeId = '||x.storeId);
      exception
        when OTHERS then
          dbms_output.put_line('import_PITP_PLACE(PITP_PONTON) storeId = '||x.storeId||' placeName = '||x.placeName||' SEGMENT AID = '||x.aid||' ERROR = '||SQLERRM);
      end;
      --commit;
    end loop;

END;
/

