create procedure update_tariff
as

begin
  update PROMOACTION_GOODS_STORES t
     set t.tariff = t.base_price
  where t.base_price > 0
    and t.tariff = 0;

  commit;
end;
/

