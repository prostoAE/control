create procedure run_table_stats
as

begin
   FOR x IN (SELECT * FROM user_tables t WHERE t.TABLE_NAME NOT LIKE 'X%')
  LOOP
     begin
      dbms_stats.gather_table_stats( ownname => 'PROMO6', tabname => x.table_name, degree => 4 );
    end;
  END LOOP;
end;
/

