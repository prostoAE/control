create package      prdContractBose_2  is

type rowContrBose_2 is record(
Year        dboanee.agreement.year%TYPE,
Buyer       dboanee.user_account.name%TYPE,
supplier    dboanee.supplier.cod_utl_supplier%TYPE,
GroupSection   dboanee.agreement.condition%TYPE,
Fiscalnumber   dboanee.agreement.nb_fiscal%TYPE,
Section        dboanee.INV_REQUEST_HEAD.id_negotiation_group%TYPE,
BoseInvoiced   number,
InvoiceNumber  dboanee.INV_REQUEST_HEAD.id_inv_request%TYPE,
dt_invoice     dboanee.INV_REQUEST_HEAD.dt_invoice%TYPE,
StoreInvoiced  dboanee.INV_REQUEST_HEAD.ID_ACC_UNIT%TYPE,
StoreTO        dboanee.INV_REQUEST_STORE.id_Store%TYPE,
Turnover       number,
Society        dboanee.INV_REQUEST_LINE.id_company%TYPE,
ServiceType   dboanee.agr_service.id_service_type%TYPE,
AgreementStatus dboanee.agreement.ID_AGR_STATUS%TYPE,
remark      dboanee.INV_REQUEST_HEAD.remark%TYPE,
Infos dboanee.agreement.infos%TYPE
);

type tblContrBose_2 is table of rowContrBose_2;

function funContractBose_2
(yr number )
return tblContrBose_2
pipelined;
end prdContractBose_2;
/

