create package body      prdContractWTSFSegm2 is
function funContractWTSFSegm2
(yr number )
return tblContractWTSFSegm2
pipelined
is
begin

if yr is null then
for curr in
(
select
    t310.N_AGREEMENT,
	t310.VERSION,
	t040.cod_utl_supplier as supplier,
	t040. Name as supplier_name,
    t315.id_negotiation_group,
    t310. Condition	 ,
  	nvl((select t356.text_Value
			from dboanee.AGR_OPTION_VALUE  t356
			where
			t356.id_Agreement = t310.id_Agreement
			and t356.id_Option = 'EDRP' and t356.ind_active

= '0'),'')
    as code_fiscal,
    t310. SHORT_CONDITION,
    t310. ID_AGR_STATUS,
    t310. ID_AGR_TYPE,
    t310.NB_FISCAL,
    t310.DT_Fiscal,
    t310.NB_SERVICE,
    t310.DT_SERVICE,
    ac.name as BUYER,
    t310.DT_CREATION,


--Rba
    nvl((select sum(t330.Rate)
		    from DBOANEE.AGR_DISCOUNT_TYPE  t330
		    where
            t330.id_Agreement = t310.id_agreement
	        and t330.id_Inv_Discount_Type = 'RBA'
	        and t330.ind_active = '1'),0)
		as Rba,

--Rpr
    nvl((select sum(t330.Rate)
			from DBOANEE.AGR_DISCOUNT_TYPE t330
			where
			t330.Id_agreement = t310.id_agreement
			and t330.ID_INV_DISCOUNT_TYPE = 'RPR'
			and t330.ind_active = '1'),0) as Rpr,

		nvl(t320.Delay,0) as DelayInDays,
		t310.TurnOver_Forecast as CA_total,

--RFAi
        nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where

            t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350.id_EYR_Type = 'RFAI'
			and t350.ind_active = '1'),0)
		as RFAi,
--RFA2
        nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR  t350
			where
            t350.id_Agreement = t310.id_agreement
			and t350. ind_Conditionnal = '0'
			and t350.id_EYR_Type = 'RFA2'
			and t350.ind_active = '1'),0)
		as RFA2,

--BOSE
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from DBOANEE.AGR_SERVICE t340
			where

			t340.id_agreement = t310.id_agreement
			and t340.id_Service_Type= 'BOSE'
			and t340.ind_active = '1'),0)
		AS BOSE,

--RMDL
		nvl((select sum(t340. BILLING_COST_PER_SERVICE)
			from DBOANEE.AGR_SERVICE  t340
			where
			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'RMDL'
			and t340. ind_active = '1'),0)
		AS RMDL,

--Bud_referencement
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from DBOANEE.AGR_SERVICE t340
			where
			t340. id_Agreement = t310. id_Agreement
	         	and t340.COOPERATION_TYPE = 'B'
			and t340.id_Service_Type = 'BORE'
			and t340.ind_active = '1'),0)
		AS BORE,


--NPAB
	nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from DBOANEE.AGR_SERVICE  t340
			where
			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'NPAB'
			and t340. ind_active = '1'), 0)
		AS NPAB,

--NRSi
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR  t350
			where
			t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'NRSI'
			and t350. ind_active = '1'), 0)
		as NRSi,

--EDI
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR  t350
			where
			t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDIW'
			and t350. ind_active = '1'), 0)
		as EDIW,

--EDIWamount
	    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN    DBOANEE.AGR_EYR

t350
	        on t355.id_agr_eyr=t350.id_agr_eyr
            Where
            t350.id_Agreement = t310.id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDIW'
    	    and t350. ind_active = '1'), 0)
		as EDIWamount,

--EDI2
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDI2'
			and t350. ind_active = '1'), 0)
		as EDI2,

--EDI2amount
	    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN  DBOANEE.AGR_EYR

t350
	        on t355.id_agr_eyr = t350.id_agr_eyr
            where
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDI2'
			and t350. ind_active = '1'), 0)
		as EDI2amount,

--RAPP
		nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type  = 'RAPP'
			and t350.ind_active = '1'),0)
		as RAPP,

--RAPP_amount
	    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN  DBOANEE.AGR_EYR

t350
	        on t355.id_agr_eyr = t350.id_agr_eyr
            where
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'RAPP'
			and t350. ind_active = '1'), 0)
		as RAPP_amount,



--CLi1
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI1'
			and t350. ind_active = '1'), 0)
		as Cli1,

--CLI1_amount
	    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN  DBOANEE.AGR_EYR

t350
	        on t355.id_agr_eyr = t350.id_agr_eyr
            where
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI1'
			and t350. ind_active = '1'), 0)
		as CLI1_amount,

--CEGA
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CEGA'
			and t350. ind_active = '1'), 0)
		as CEGA,

--SPI%
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'SPI%'
			and t350. ind_active = '1'), 0)
		as SPI,

--PGL1
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'PGL1'
			and t350.ind_active = '1'),0)
	as PGL1,

--PGL2
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'PGL2'
			and t350.ind_active = '1'),0)
	as PGL2,

--RFCC
	nvl((select max(t353.Rate)
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where
			t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFCC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'),0)
        as RFCc,


--DATA
		nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'DATA'
			and t350.ind_active = '1'),0)
		as DATA,

--CLi2
		nvl((select sum(t350. Rate)
			from AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI2'
			and t350. ind_active = '1'), 0)
		as Cli2,

--Degustation (DPSC)
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type  = 'DPSC'
			and t340.ind_active  = '1'),0)
		AS DPSC,

--TGsc
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'TGSC'
			and t340.ind_active = '1'),0)
		AS TGSC,

--Pisc
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'PISC'
			and t340.ind_active = '1'),0)
		AS PISC,

--Ppsc
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'PPSC'
			and t340.ind_active = '1'),0)
			AS Ppsc,

--Zpsc
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'ZPSC'
			and t340.ind_active = '1'),0)
		AS Zpsc,

--PSsc
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where
			t340. id_Agreement = t310. id_Agreement
			and t340.Id_service_type = 'PSSC'
			and t340.ind_active = '1'),0) AS PSsc,


--ZPHS_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0)
         AS ZPHS,


--TGHS_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGHS'
			and t340.ind_active = '1'), 0)
		AS TGHS,


--PSHS_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSHS'
			and t340.ind_active = '1'), 0)
		AS PSHS,

--PPHS_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPHS'
			and t340.ind_active = '1'),0)
		AS PPHS,


--PIHS_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PIHS'
			and t340.ind_active = '1'),0)  AS PIHS,


--DPHS_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'DPHS'
			and t340.ind_active = '1'),0)  AS DPHS,

--Sibo
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'SIBO'
			and t340.ind_active = '1'),0) AS Sibo,

--Code
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'CODE'
			and t340.ind_active = '1'),0)
		AS Code,

--RFAc

		nvl((select max(t353.Rate)
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where
			t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFAC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'),0)
        as RFAc,

	Infos

	from
	dboanee.AGREEMENT  t310 inner join
	dboanee.SUPPLIER   t040 on
		t310.id_supplier = t040. id_supplier
		left outer join dboanee.AGR_PAYMENT  t320 on
		t310.id_agreement= t320.id_agreement
		and t320.id_Payment_Type = 'TERM'

    join dboanee.AGR_CONDITION t315 on
        t310.id_agreement = t315.id_agreement

   left join dboanee.negotiation_group  ng
   on t315.id_supplier=ng.id_supplier
   and substr(t315.id_negotiation_group, 1,3)=ng.id_negotiation_group

   left join dboanee.user_account ac
   on ng.id_user_account=ac.id_user_account

	where
t310.id_agr_status    in ('WFS', 'SGN', 'CAN', 'INK')

) loop
pipe row (curr);
end loop;
else

for curr in
(
select
    t310.N_AGREEMENT,
	t310.VERSION,
	t040.cod_utl_supplier as supplier,
	t040. Name as supplier_name,
    t315.id_negotiation_group,
    t310. Condition	 ,
  	nvl((select t356.text_Value
			from dboanee.AGR_OPTION_VALUE  t356
			where
			t356.id_Agreement = t310.id_Agreement
			and t356.id_Option = 'EDRP' and t356.ind_active

= '0'),'')
    as code_fiscal,
    t310. SHORT_CONDITION,
    t310. ID_AGR_STATUS,
    t310. ID_AGR_TYPE,
    t310.NB_FISCAL,
    t310.DT_Fiscal,
    t310.NB_SERVICE,
    t310.DT_SERVICE,
    ac.name as BUYER,
    t310.DT_CREATION,


--Rba
    nvl((select sum(t330.Rate)
		    from DBOANEE.AGR_DISCOUNT_TYPE  t330
		    where   t310.Year = yr  and
            t330.id_Agreement = t310.id_agreement
	        and t330.id_Inv_Discount_Type = 'RBA'
	        and t330.ind_active = '1'),0)
		as Rba,

--Rpr
    nvl((select sum(t330.Rate)
			from DBOANEE.AGR_DISCOUNT_TYPE t330
			where t310.Year = yr
			and t330.Id_agreement = t310.id_agreement
			and t330.ID_INV_DISCOUNT_TYPE = 'RPR'
			and t330.ind_active = '1'),0) as Rpr,

		nvl(t320.Delay,0) as DelayInDays,
		t310.TurnOver_Forecast as CA_total,

--RFAi
        nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where
            t310.Year = yr  and
            t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350.id_EYR_Type = 'RFAI'
			and t350.ind_active = '1'),0)
		as RFAi,
--RFA2
        nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR  t350
			where t310.Year = yr  and
            t350.id_Agreement = t310.id_agreement
			and t350. ind_Conditionnal = '0'
			and t350.id_EYR_Type = 'RFA2'
			and t350.ind_active = '1'),0)
		as RFA2,

--Bud_ouv
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from DBOANEE.AGR_SERVICE t340
			where
			t310.Year = yr  and
			t340.id_agreement = t310.id_agreement
			and t340.id_Service_Type= 'BOSE'
			and t340.ind_active = '1'),0)
		AS BOSE,

--RMDL
		nvl((select sum(t340. BILLING_COST_PER_SERVICE)
			from DBOANEE.AGR_SERVICE  t340
			where t310.Year = yr  and
			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'RMDL'
			and t340. ind_active = '1'),0)
		AS RMDL,

--Bud_referencement
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from DBOANEE.AGR_SERVICE t340
			where  t310.Year = yr  and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'BORE'
			and t340.ind_active = '1'),0)
		AS BORE,


--New_pos
	nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from DBOANEE.AGR_SERVICE  t340
			where t310.Year = yr  and
			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'NPAB'
			and t340. ind_active = '1'), 0)
		AS NPAB,

--NRSi
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR  t350
			where t310.Year = yr  and
			t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'NRSI'
			and t350. ind_active = '1'), 0)
		as NRSi,

--EDI
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR  t350
			where t310.Year = yr  and
			t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDIW'
			and t350. ind_active = '1'), 0)
		as EDIW,

--EDIWamount
	    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN    DBOANEE.AGR_EYR

t350
	        on t355.id_agr_eyr=t350.id_agr_eyr
            Where t310.Year = yr  and
            t350.id_Agreement = t310.id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDIW'
    	    and t350. ind_active = '1'), 0)
		as EDIWamount,

--EDI2
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			t310.Year = yr  and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDI2'
			and t350. ind_active = '1'), 0)
		as EDI2,

--EDI2amount
	    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN  DBOANEE.AGR_EYR

t350
	        on t355.id_agr_eyr = t350.id_agr_eyr
            where  t310.Year = yr  and
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDI2'
			and t350. ind_active = '1'), 0)
		as EDI2amount,

--RAPP
		nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where t310.Year = yr  and
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type  = 'RAPP'
			and t350.ind_active = '1'),0)
		as RAPP,

--RAPP_amount
	    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN  DBOANEE.AGR_EYR

t350
	        on t355.id_agr_eyr = t350.id_agr_eyr
            where  t310.Year = yr  and
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'RAPP'
			and t350. ind_active = '1'), 0)
		as RAPP_amount,



--CLi1
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year = yr  and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI1'
			and t350. ind_active = '1'), 0)
		as Cli1,

--CLI1_amount
	    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN  DBOANEE.AGR_EYR

t350
	        on t355.id_agr_eyr = t350.id_agr_eyr
            where  t310.Year = yr  and
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI1'
			and t350. ind_active = '1'), 0)
		as CLI1amount,

--CEGA
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CEGA'
			and t350. ind_active = '1'), 0)
		as CEGA,

--SPI%
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'SPI%'
			and t350. ind_active = '1'), 0)
		as SPI,

--PGL1
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'PGL1'
			and t350.ind_active = '1'),0)
	as PGL1,

--PGL2
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year = yr  and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'PGL2'
			and t350.ind_active = '1'),0)
	as PGL2,

--RFCC
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'RFCC'
			and t350.ind_active = '1'),0)
	as RFCC,


--DATA
		nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where t310.Year = yr  and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'DATA'
			and t350.ind_active = '1'),0)
		as DATA,

--CLi2
		nvl((select sum(t350. Rate)
			from AGR_EYR   t350
			where
			t310.Year = yr  and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI2'
			and t350. ind_active = '1'), 0)
		as Cli2,

--Degustation
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where t310.Year = yr  and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type  = 'DPSC'
			and t340.ind_active  = '1'),0)
		AS DPSC,

--TGsc
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where  t310.Year = yr  and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'TGSC'
			and t340.ind_active = '1'),0)
		AS TGSC,

--Pisc
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where t310.Year = yr  and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'PISC'
			and t340.ind_active = '1'),0)
		AS PISC,

--Ppsc
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where t310.Year = yr  and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'PPSC'
			and t340.ind_active = '1'),0)
			AS Ppsc,

--Zpsc
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where t310.Year = yr  and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'ZPSC'
			and t340.ind_active = '1'),0)
		AS Zpsc,

--PSsc
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where t310.Year = yr  and
			t340. id_Agreement = t310. id_Agreement
			and t340.Id_service_type = 'PSSC'
			and t340.ind_active = '1'),0) AS PSsc,


--ZPHS_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where t310.year = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0)
         AS ZPHS,


--TGHS_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where t310.year = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGHS'
			and t340.ind_active = '1'), 0)
		AS TGHS,


--PSHS_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where t310.year = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSHS'
			and t340.ind_active = '1'), 0)
		AS PSHS,

--PPHS_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where t310.year = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPHS'
			and t340.ind_active = '1'),0)
		AS PPHS,


--PIHS_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where t310.year = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PIHS'
			and t340.ind_active = '1'),0)  AS PIHS,


--DPHS_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where t310.year = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'DPHS'
			and t340.ind_active = '1'),0)  AS DPHS,

--Sibo
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where t310.Year = yr  and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'SIBO'
			and t340.ind_active = '1'),0) AS Sibo,

--Code
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where t310.Year = yr  and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'CODE'
			and t340.ind_active = '1'),0)
		AS Code,

--RFAc

		nvl((select max(t353.Rate)
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where t310.Year = yr
			and t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFAC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'),0)
        as RFAc,

	Infos

	from
	dboanee.AGREEMENT  t310 inner join
	dboanee.SUPPLIER   t040 on
		t310.id_supplier = t040. id_supplier
		left outer join dboanee.AGR_PAYMENT  t320 on
		t310.id_agreement= t320.id_agreement
		and t320.id_Payment_Type = 'TERM'

    join dboanee.AGR_CONDITION t315 on
        t310.id_agreement = t315.id_agreement

   left join dboanee.negotiation_group  ng
   on t315.id_supplier=ng.id_supplier
   and substr(t315.id_negotiation_group, 1,3)=ng.id_negotiation_group

   left join dboanee.user_account ac
   on ng.id_user_account=ac.id_user_account

	where

    t310.year = yr

	and t310.id_agr_status    in ('WFS', 'SGN', 'CAN', 'INK')

and t310.version= (select max(version)
                   from dboanee.agreement agr
                  where t310.n_agreement=agr.n_agreement
                   and agr.id_agr_status in ('SGN', 'CAN', 'WFS', 'INK')
                   and agr.year=yr)


) loop
pipe row (curr);
end loop;
end if;
end funContractWTSFSegm2;
end prdContractWTSFSegm2;
/

