create type        SYS_PLSQL_48443_187_1 as table of "ANEE"."SYS_PLSQL_48443_9_1";
/

