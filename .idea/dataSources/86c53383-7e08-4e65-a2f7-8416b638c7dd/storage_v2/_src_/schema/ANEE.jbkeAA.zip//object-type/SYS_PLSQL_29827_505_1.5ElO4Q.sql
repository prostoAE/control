create type        SYS_PLSQL_29827_505_1 as table of "ANEE"."SYS_PLSQL_29827_9_1";
/

