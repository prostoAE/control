create type        SYS_PLSQL_28501_DUMMY_1 as table of number;
/

