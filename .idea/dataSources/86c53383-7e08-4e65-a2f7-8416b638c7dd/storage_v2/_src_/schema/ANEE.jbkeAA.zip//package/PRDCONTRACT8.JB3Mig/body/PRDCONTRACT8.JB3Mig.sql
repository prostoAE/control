create package body      prdContract8 is
function funContract8
(yr number )
return tblContr8
pipelined
is
begin
for curr in
(
select DISTINCT
  t310.N_AGREEMENT,
  t310.VERSION,
  t310. ID_AGR_STATUS,
  t310. SHORT_CONDITION,
  ac.name as BUYER,
  t040.cod_utl_supplier as supplier,
  t040. Name as supplier_name,
  t310.NB_FISCAL,
  t310.DT_Fiscal,
  t310.NB_SERVICE,
  t310.DT_SERVICE,
  t310. Condition as Segments,
  nvl((select t356.text_Value
  from dboanee.agr_option_value t356
  where
  t356.id_agreement = t310.id_agreement
  and t356.id_option = 'EDRP'
  and t356.ind_active = '1'),'')
  as code_fiscal,
  nvl(t320.Delay,0) as DelayInDays,
  t310.TurnOver_Forecast as CA_total,

--Rba
    nvl((select sum(t330.Rate)
        from DBOANEE.AGR_DISCOUNT_TYPE  t330
        where   t310.year = yr  and
            t330.id_Agreement = t310.id_agreement
          and t330.id_Inv_Discount_Type = 'RBA'
          and t330.ind_active = '1'),0)
  as Rba,

--Rpr
    nvl((select sum(t330.Rate)
      from DBOANEE.AGR_DISCOUNT_TYPE t330
      where t310.year = yr
      and t330.Id_agreement = t310.id_agreement
      and t330.ID_INV_DISCOUNT_TYPE = 'RPR'
      and t330.ind_active = '1'),0)
  as Rpr,

--RFAi
    nvl((select sum(t350.Rate)
      from DBOANEE.AGR_EYR t350
      where
            t310.year = yr  and
            t350.id_Agreement = t310.id_agreement
      and t350.ind_Conditionnal = '0'
      and t350.id_EYR_Type = 'RFAI'
      and t350.ind_active = '1'),0)
  as RFAi,

--RFA2
    nvl((select sum(t350.Rate)
      from DBOANEE.AGR_EYR  t350
      where t310.year = yr  and
            t350.id_Agreement = t310.id_agreement
      and t350. ind_Conditionnal = '0'
      and t350.id_EYR_Type = 'RFA2'
      and t350.ind_active = '1'),0)
  as RFA2,

--CLi1 (new name  R_Log)
  nvl((select sum(t350. Rate)
      from DBOANEE.AGR_EYR   t350
      where
       t310.year = yr  and
      t350. id_Agreement = t310. id_Agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'CLI1'
      and t350. ind_active = '1'), 0)
  as Cli1,

--Cli1_amount

    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN    DBOANEE.AGR_EYR  t350
          on t355.id_agr_eyr=t350.id_agr_eyr
            Where t310.year = yr  and
            t350.id_Agreement = t310.id_Agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'CLI1'
          and t350. ind_active = '1'), 0)
    as Cli1_amount,


--DATA
    nvl((select sum(t350.Rate)
      from DBOANEE.AGR_EYR t350
      where t310.year = yr  and
      t350. id_Agreement = t310. id_Agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'DATA'
      and t350.ind_active = '1'),0)
  as DATA,


--CLi2
  nvl((select sum(t350. Rate)
      from AGR_EYR   t350
      where
      t310.year = yr  and
      t350. id_Agreement = t310. id_Agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'CLI2'
      and t350. ind_active = '1'), 0)
  as Cli2,

--EDI
  nvl((select sum(t350. Rate)
      from DBOANEE.AGR_EYR  t350
      where t310.year = yr  and
      t350.id_Agreement = t310.id_agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'EDIW'
      and t350. ind_active = '1'), 0)
  as EDI,

--EDIWamount

    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN    DBOANEE.AGR_EYR  t350
          on t355.id_agr_eyr=t350.id_agr_eyr
            Where t310.year = yr  and
            t350.id_Agreement = t310.id_Agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'EDIW'
          and t350. ind_active = '1'), 0)
    as EDIWamount,

--EDI2
    nvl((select sum(t350. Rate)
      from DBOANEE.AGR_EYR   t350
      where
      t310.year = yr  and
      t350. id_Agreement = t310. id_Agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'EDI2'
      and t350. ind_active = '1'), 0)
    as EDI2,

--EDI2amount
   nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN  DBOANEE.AGR_EYR  t350
          on t355.id_agr_eyr = t350.id_agr_eyr
            where  t310.year = yr  and
            t350.id_Agreement = t310. id_Agreement
            and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'EDI2'
      and t350. ind_active = '1'), 0)
    as EDI2amount,

--RAPP
  nvl((select sum(t350.Rate)
      from DBOANEE.AGR_EYR t350
      where t310.year = yr  and
            t350.id_Agreement = t310. id_Agreement
            and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type  = 'RAPP'
      and t350.ind_active = '1'),0)
  as RAPP,

--RAPP_amount
   nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN  DBOANEE.AGR_EYR  t350
          on t355.id_agr_eyr = t350.id_agr_eyr
            where  t310.year = yr  and
            t350.id_Agreement = t310. id_Agreement
            and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'RAPP'
      and t350. ind_active = '1'), 0)
    as RAPP_amount,



--RFAc
    nvl((select max(t353.Rate)
      from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
      where t310.year = yr
      and t350.Id_agreement = t310.id_agreement
      and t350.Id_eyr_type = 'RFAC'
      and t353.ind_active = '1'
      and t350.ind_active = '1'),0)
    as RFAc,

--CEGA
  nvl((select sum(t350. Rate)
      from DBOANEE.AGR_EYR   t350
      where
       t310.year = yr  and
      t350. id_Agreement = t310. id_Agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'CEGA'
      and t350.ind_active = '1'),0)
  as CEGA,

--SPi%
  nvl((select sum(t350. Rate)
      from DBOANEE.AGR_EYR   t350
      where
       t310.year = yr  and
      t350. id_Agreement = t310. id_Agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'SPI%'
      and t350.ind_active = '1'),0)
  as SPi,


--PGl1
  nvl((select sum(t350. Rate)
      from DBOANEE.AGR_EYR   t350
      where
       t310.year = yr  and
      t350. id_Agreement = t310. id_Agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'PGL1'
      and t350.ind_active = '1'),0)
  as PGl1,

--PGL2
  nvl((select sum(t350. Rate)
      from DBOANEE.AGR_EYR   t350
      where
       t310.year = yr  and
      t350. id_Agreement = t310. id_Agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'PGL2'
      and t350.ind_active = '1'),0)
  as PGL2,

--RFCC
  nvl((select sum(t350. Rate)
      from DBOANEE.AGR_EYR   t350
      where
       t310.year = yr  and
      t350. id_Agreement = t310. id_Agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'RFCC'
      and t350.ind_active = '1'),0)
  as RFCC,

--NRSi
  nvl((select sum(t350. Rate)
      from DBOANEE.AGR_EYR  t350
      where t310.year = yr  and
      t350.id_Agreement = t310.id_agreement
      and t350.ind_Conditionnal = '0'
      and t350. id_EYR_Type = 'NRSI'
      and t350. ind_active = '1'), 0)
  as NRSi,

--BOSE (openning budget)
  nvl((select sum(t340.BILLING_COST_PER_SERVICE)
      from DBOANEE.AGR_SERVICE t340
      where
      t310.year = yr  and
      t340.id_agreement = t310.id_agreement
      and t340.id_Service_Type= 'BOSE'
      and t340.ind_active = '1'),0)
  AS BOSE,


--BOSE_Amount
  nvl((select sum(t340.TOTAL_AMOUNT)
      from DBOANEE.AGR_SERVICE t340
      where
      t310.year = yr  and
      t340.id_agreement = t310.id_agreement
      and t340.id_Service_Type= 'BOSE'
      and t340.ind_active = '1'),0)
  AS BOSE_Amount,

--RMDL Remodeling
    nvl((select sum(t340. BILLING_COST_PER_SERVICE)
      from DBOANEE.AGR_SERVICE  t340
      where t310.year = yr  and
      t340.id_agreement = t310.id_agreement
      and t340. id_Service_Type = 'RMDL'
      and t340. ind_active = '1'),0)
  AS RMDL,

--new position
  nvl((select sum(t340.Total_Amount)
      from DBOANEE.AGR_SERVICE  t340
      where t310.year = yr  and
      t340.id_agreement = t310.id_agreement
      and t340. id_Service_Type = 'NPAB'
      and t340. ind_active = '1'), 0)
  AS New_pos,


--Code
  nvl((select sum(t340.TOTAL_AMOUNT)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr  and
      t340. id_Agreement = t310. id_Agreement
           and t340.id_Service_Type = 'CODE'
      and t340.ind_active = '1'),0)
  AS Code,

-------------------------------------------------------------------------
--ZPHS_Cost1
  nvl((select sum(t340.Billing_Cost_Per_Service)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ZPHS'
      and t340.ind_active = '1'), 0)
     AS ZPHS_Cost1,

--ZPHS_QtyPerStore
    nvl((select sum(t340.Qty_Per_Store)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'ZPHS'
      and t340.ind_active = '1'),0) AS ZPHS_QtyPerStore,

--ZPHS_TotalQty
  nvl((select sum(t340.Total_Qty)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'ZPHS'
      and t340.ind_active = '1'),0)
  AS ZPHS_TotalQty,

--ZPHS_TotalAmount
  nvl((select sum(t340.Total_Amount)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'ZPHS'
      and t340.ind_active = '1'),0)
  AS ZPHS_TotalAmount,

--TGHS_Cost1
  nvl((select sum(t340.Billing_Cost_Per_Service)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'TGHS'
      and t340.ind_active = '1'), 0)
  AS TGHS_Cost1,

--TGHS_QtyPerStore
  nvl((select sum(t340.Qty_Per_Store)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'TGHS'
      and t340.ind_active = '1'),0)
  AS TGHS_QtyPerStore,

--TGHS_TotalQty
  nvl((select sum(t340.Total_Qty)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'TGHS'
      and t340.ind_active = '1'),0)
  AS TGHS_TotalQty,

--TGHS_TotalAmount
  nvl((select sum(t340.Total_Amount)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'TGHS'
      and t340.ind_active = '1'),0)
  AS TGHS_TotalAmount,

--PSHS_Cost1
  nvl((select sum(t340.Billing_Cost_Per_Service)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PSHS'
      and t340.ind_active = '1'), 0)
    AS PSHS_Cost1,

--PSHS_QtyPerStore
  nvl((select sum(t340.Qty_Per_Store)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'PSHS'
      and t340.ind_active = '1'),0)
  AS PSHS_QtyPerStore,

--PSHS_TotalQty
  nvl((select sum(t340.Total_Qty)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'PSHS'
      and t340.ind_active = '1'),0)
  AS PSHS_TotalQty,

--PSHS_TotalAmount
  nvl((select sum(t340.Total_Amount)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'PSHS'
      and t340.ind_active = '1'),0)
  AS PSHS_TotalAmount,

--PPHS_Cost1
  nvl((select sum(t340.Billing_Cost_Per_Service)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PPHS'
      and t340.ind_active = '1'),0)
    AS PPHS_Cost1,


--PPHS_QtyPerStore
  nvl((select sum(t340.Qty_Per_Store)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'PPHS'
      and t340.ind_active = '1'),0)  AS PPHS_QtyPerStore,

--PPHS_TotalQty
    nvl((select sum(t340.Total_Qty)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'PPHS'
      and t340.ind_active = '1'),0)  AS PPHS_TotalQty,

--PPHS_TotalAmount
    nvl((select sum(t340.Total_Amount)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'PPHS'
      and t340.ind_active = '1'),0)  AS PPHS_TotalAmount,

--PIHS_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from dboanee.AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PIHS'
      and t340.ind_active = '1'),0)  AS PIHS_Cost1,

--PIHS_Qty_Per_Store
    nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE  t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PIHS'
      and t340.ind_active = '1'), 0) AS PIHS_Qty_Per_Store,

--PIHS_Total_Qty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PIHS'
      and t340.ind_active = '1'), 0) AS PIHS_TotalQty,

--PIHS_Total_Amount
    nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PIHS'
      and t340.ind_active = '1'), 0) AS PIHS_Total_Amount,


--DPHS_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'DPHS'
      and t340.ind_active = '1'),0) AS DPHS_Cost1,

--DPHS_Qty_Per_Store
    nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'DPHS'
      and t340.ind_active = '1'), 0) AS DPHS_Qty_Per_Store,

--DPHS_Total_Qty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'DPHS'
      and t340.ind_active = '1'), 0) AS DPHS_TotalQty,

--DPHS_Total_Amount
    nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'DPHS'
      and t340.ind_active = '1'), 0) AS DPHS_Total_Amount,

-------------------------------------------------------------------------
--Sibo
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'SIBO'
      and t340.ind_active = '1'), 0) AS Sibo,



--DPSC_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE   t340
      where
       t310.year = yr  and
      t340. id_Agreement = t310. id_Agreement
      and t340.id_Service_Type = 'DPSC'
      and t340.ind_active = '1'), 0) AS DPSC_Cost1,

--DPSC_Qty_Per_Store
    nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE    t340
      where
       t310.year = yr  and
      t340. id_Agreement = t310. id_Agreement
      and t340. id_Service_Type = 'DPSC'
      and t340. ind_active = '1'), 0) AS DPSC_Qty_Per_Store,

--DPSC_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE  t340
      where
       t310.year = yr  and
      t340. id_Agreement = t310. id_Agreement
      and t340. id_Service_Type = 'DPSC'
      and t340. ind_active = '1'), 0) AS DPSC_TotalQty,

--DPSC_Total_Amount
    nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE  t340
      where
       t310.year = yr  and
      t340. id_Agreement = t310. id_Agreement
      and t340. id_Service_Type = 'DPSC'
      and t340. ind_active = '1'), 0) AS DPSC_Total_Amount,

--TGSC_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'TGSC'
      and t340.ind_active = '1'), 0) AS TGSC_Cost1,

--TGsc_Qty_Per_Store
    nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'TGSC'
      and t340.ind_active = '1'), 0) AS TGSC_Qty_Per_Store,

--TGsc_Total_Qty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'TGSC'
      and t340.ind_active = '1'), 0) AS TGSC_TotalQty,

--TGsc_Total_Amount
    nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'TGSC'
      and t340.ind_active = '1'), 0) AS TGSC_Total_Amount,


--PISC_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PISC'
      and t340.ind_active = '1'), 0) AS PISC_Cost1,

--PISC_Qty_Per_Store
    nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PISC'
      and t340.ind_active = '1'), 0) AS PISC_Qty_Per_Store,

--PISC_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PISC'
      and t340.ind_active = '1'),0) AS PISC_TotalQtyO,

--PISC_Total_Amount
    nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PISC'
      and t340.ind_active = '1'), 0) AS PISC_Total_Amount,

--PPSC_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PPSC'
      and t340.ind_active = '1'), 0) AS PPSC_Cost1,

--PPSC_Qty_Per_Store
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PPSC'
      and t340.ind_active = '1'), 0)
  AS PPSC_Qty_Per_Store,

--PPSC_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PPSC'
      and t340.ind_active = '1'), 0) AS PPSC_TotalQty,

--PPSC_Total_Amount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PPSC'
      and t340.ind_active = '1'), 0)
  AS PPSC_Total_Amount,


--PSsc_Cost1
  nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PSSC'
      and t340.ind_active = '1'), 0)
  AS PSsc_Cost1,

--PSsc_QtyPerStore
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PSSC'
      and t340.ind_active = '1'), 0)
  AS PSSC_Qty_Per_Store,

--PSsc_TotalQtyOfService
  nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PSSC'
      and t340.ind_active = '1'), 0)
  AS PSsc_TotalQty,

--Pssc_TotalAmount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PSSC'
      and t340.ind_active = '1'), 0)
  AS PSsc_TotalAmount,

--ZPSC_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ZPSC'
      and t340.ind_active = '1'), 0) AS ZPSC_Cost1,

--ZPSC_Qty_Per_Store
    nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ZPSC'
      and t340.ind_active = '1'), 0) AS ZPSC_Qty_Per_Store,

--ZPSC_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ZPSC'
      and t340.ind_active = '1'), 0) AS ZPSC_TotalQty,

--ZPSC_Total_Amount
    nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where
                        t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ZPSC'
      and t340.ind_active = '1'), 0) AS ZPSC_Total_Amount,

--MRKD
  nvl((select sum(t340.BILLING_COST_PER_SERVICE)
      from DBOANEE.AGR_SERVICE t340
      where
       t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.id_Service_Type= 'MRKD'
      and t340.ind_active = '1'),0)
  AS MRKD,


--MRKD_Amount
  nvl((select sum(t340.TOTAL_AMOUNT)
      from DBOANEE.AGR_SERVICE t340
      where
                        t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.id_Service_Type= 'MRKD'
      and t340.ind_active = '1'),0)
  AS MRKD_Amount,

--BOSF
  nvl((select sum(t340.BILLING_COST_PER_SERVICE)
      from DBOANEE.AGR_SERVICE t340
      where
                        t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.id_Service_Type= 'BOSF'
      and t340.ind_active = '1'),0)
  AS BOSF,


--BOSF_Amount
  nvl((select sum(t340.TOTAL_AMOUNT)
      from DBOANEE.AGR_SERVICE t340
      where
                        t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.id_Service_Type= 'BOSF'
      and t340.ind_active = '1'),0)
  AS BOSF_Amount,

--SITC_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where
      t310.year = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'SITC'
      and t340.ind_active = '1'), 0) AS SITC_Cost1,

--SITC_Qty_Per_Store
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'SITC'
      and t340.ind_active = '1'), 0)
  AS SITC_Qty_Per_Store,

--SITC_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'SITC'
      and t340.ind_active = '1'), 0) AS SITC_TotalQty,

--SITC_Total_Amount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where
       t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'SITC'
      and t340.ind_active = '1'), 0)
  AS SITC_Total_Amount,

--NPSF_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'NPSF'
      and t340.ind_active = '1'), 0) AS NPSF_Cost1,

--NPSF_Qty_Per_Store
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'NPSF'
      and t340.ind_active = '1'), 0)
  AS NPSF_Qty_Per_Store,

--NPSF_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'NPSF'
      and t340.ind_active = '1'), 0) AS NPSF_TotalQty,

--NPSF_Total_Amount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where
       t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'NPSF'
      and t340.ind_active = '1'), 0)
  AS NPSF_Total_Amount,

--DPSF_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'DPSF'
      and t340.ind_active = '1'), 0) AS DPSF_Cost1,

--DPSF_Qty_Per_Store
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'DPSF'
      and t340.ind_active = '1'), 0)
  AS DPSF_Qty_Per_Store,

--DPSF_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'DPSF'
      and t340.ind_active = '1'), 0) AS DPSF_TotalQty,

--DPSF_Total_Amount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'DPSF'
      and t340.ind_active = '1'), 0)
  AS DPSF_Total_Amount,

--PISF_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PISF'
      and t340.ind_active = '1'), 0) AS PISF_Cost1,

--PISF_Qty_Per_Store
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PISF'
      and t340.ind_active = '1'), 0)
  AS PISF_Qty_Per_Store,

--PISF_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PISF'
      and t340.ind_active = '1'), 0) AS PISF_TotalQty,

--PISF_Total_Amount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PISF'
      and t340.ind_active = '1'), 0)
  AS PISF_Total_Amount,

--PPSF_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PPSF'
      and t340.ind_active = '1'), 0) AS PPSF_Cost1,

--PPSF_Qty_Per_Store
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PPSF'
      and t340.ind_active = '1'), 0)
  AS PPSF_Qty_Per_Store,

--PPSF_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where
     t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PPSF'
      and t340.ind_active = '1'), 0) AS PPSF_TotalQty,

--PPSF_Total_Amount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where
       t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PPSF'
      and t340.ind_active = '1'), 0)
  AS PPSF_Total_Amount,

--PSSF_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where
     t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PSSF'
      and t340.ind_active = '1'), 0) AS PSSF_Cost1,

--PSSF_Qty_Per_Store
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PSSF'
      and t340.ind_active = '1'), 0)
  AS PSSF_Qty_Per_Store,

--PSSF_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PSSF'
      and t340.ind_active = '1'), 0) AS PSSF_TotalQty,

--PSSF_Total_Amount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PSSF'
      and t340.ind_active = '1'), 0)
  AS PSSF_Total_Amount,

--ANN2_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ANN2'
      and t340.ind_active = '1'), 0) AS ANN2_Cost1,

--ANN2_Qty_Per_Store
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where
     t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ANN2'
      and t340.ind_active = '1'), 0)
  AS ANN2_Qty_Per_Store,

--ANN2_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where
       t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ANN2'
      and t340.ind_active = '1'), 0) AS ANN2_TotalQty,

--ANN2_Total_Amount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where
       t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ANN2'
      and t340.ind_active = '1'), 0)
  AS ANN2_Total_Amount,

--TGSF_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'TGSF'
      and t340.ind_active = '1'), 0) AS TGSF_Cost1,

--TGSF_Qty_Per_Store
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'TGSF'
      and t340.ind_active = '1'), 0)
  AS TGSF_Qty_Per_Store,

--TGSF_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where
     t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'TGSF'
      and t340.ind_active = '1'), 0) AS TGSF_TotalQty,

--TGSF_Total_Amount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'TGSF'
      and t340.ind_active = '1'), 0)
  AS TGSF_Total_Amount,


--ZPSF_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where
     t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ZPSF'
      and t340.ind_active = '1'), 0) AS ZPSF_Cost1,

--ZPSF_Qty_Per_Store
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ZPSF'
      and t340.ind_active = '1'), 0)
  AS ZPSF_Qty_Per_Store,

--ZPSF_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ZPSF'
      and t340.ind_active = '1'), 0) AS ZPSF_TotalQty,

--ZPSF_Total_Amount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ZPSF'
      and t340.ind_active = '1'), 0)
  AS ZPSF_Total_Amount,


--NPEF_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'NPEF'
      and t340.ind_active = '1'), 0) AS NPEF_Cost1,

--NPEF_Qty_Per_Store
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'NPEF'
      and t340.ind_active = '1'), 0)
  AS NPEF_Qty_Per_Store,

--NPEF_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'NPEF'
      and t340.ind_active = '1'), 0) AS NPEF_TotalQty,

--NPEF_Total_Amount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'NPEF'
      and t340.ind_active = '1'), 0)
  AS NPEF_Total_Amount,

--ANNV_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ANNV'
      and t340.ind_active = '1'), 0) AS ANNV_Cost1,

--ANNV_Qty_Per_Store
  nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where
      t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ANNV'
      and t340.ind_active = '1'), 0)
  AS ANNV_Qty_Per_Store,

--ANNV_TotalQty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where
     t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ANNV'
      and t340.ind_active = '1'), 0) AS ANNV_TotalQty,

--ANNV_Total_Amount
  nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where
     t310.year = yr and
      t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'ANNV'
      and t340.ind_active = '1'), 0)
  AS ANNV_Total_Amount,

    Infos

  from
  dboanee.AGREEMENT  t310 inner join
  dboanee.SUPPLIER  t040 on
  t310.id_supplier = t040. id_supplier

  left outer join dboanee.AGR_PAYMENT  t320 on
  t310.id_agreement= t320.id_agreement and t320.id_Payment_Type = 'TERM'

        join dboanee.AGR_CONDITION t315 on
        t310.id_agreement = t315.id_agreement

        left join dboanee.negotiation_group  ng
        on t315.id_supplier=ng.id_supplier
        and substr(t315.id_negotiation_group, 1,3)=ng.id_negotiation_group

        left join dboanee.user_account ac
        on ng.id_user_account=ac.id_user_account

       where
       t310.year = yr
       and t310.id_agr_status    in ('NTG', 'NDM', 'NRA')
     /*  and t310.version= (select max(version)
                   from dboanee.agreement agr
                  where t310.n_agreement=agr.n_agreement
                   and agr.id_agr_status in ('NTG', 'NDM', 'NRA')
                   and agr.year= yr)*/


) loop
pipe row (curr);
end loop;

end funContract8;
end prdContract8;
/

