create type        SYS_PLSQL_28443_DUMMY_1 as table of number;
/

