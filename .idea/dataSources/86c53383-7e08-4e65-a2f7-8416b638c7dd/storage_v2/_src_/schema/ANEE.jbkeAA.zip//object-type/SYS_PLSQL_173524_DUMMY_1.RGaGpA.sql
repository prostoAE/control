create type        SYS_PLSQL_173524_DUMMY_1 as table of number;
/

