create package body      prdContractWTSFCDG is
function funContractWTSFCDG
(yr number )
return tblContrWTSFCDG
pipelined
is
begin

if yr is null then
for curr in
(
select distinct
		t310.N_AGREEMENT,
		t310.VERSION,
		t040.cod_utl_supplier as supplier,
		t040. Name as supplier_name,
	        t310. Condition,
  	nvl((select t356.text_Value
			from AGR_OPTION_VALUE  t356
			where
			t356.id_Agreement = t310.id_Agreement
			and t356.id_Option = 'EDRP'),'')
               as code_fiscal,
		ac.name as BUYER,
			t310. SHORT_CONDITION,
			t310. ID_AGR_STATUS,
			t310. ID_AGR_TYPE ,
			t310.NB_FISCAL,
                        t310.DT_Fiscal,
                        t310.NB_SERVICE,
                        t310.DT_SERVICE,


--Rba
  		nvl((select sum(t330.Rate)
		from AGR_DISCOUNT_TYPE  t330
		where

          t330.id_Agreement = t310.id_agreement
			and t330.id_Inv_Discount_Type = 'RBA'
			and t330.ind_active = '1'),0) as Rba

--Rba_remark
        ,nvl((select t330.Remark
	from DBOANEE.AGR_DISCOUNT_TYPE  t330
	 where
            t330.id_Agreement = t310.id_agreement
	        and t330.id_Inv_Discount_Type = 'RBA'
	        and t330.ind_active = '1'),0)
		as Rba_remark

--Rpr
  		, nvl((select sum(t330.Rate)
			from AGR_DISCOUNT_TYPE t330
			where
			t330.Id_agreement = t310.id_agreement
			and t330.ID_INV_DISCOUNT_TYPE = 'RPR'
			and t330.ind_active = '1'),0) as Rpr,

			nvl(t320.Delay,0) as DelayInDays,
		 t310.TurnOver_Forecast as CA_total,


--CEGA
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CEGA'
			and t350. ind_active = '1'), 0)
		as CEGA,


--CLi1
		nvl((select sum(t350. Rate)
			from AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI1'
			and t350. ind_active = '1'), 0) as Cli1,

--Cli1_amount
	nvl((select sum(t355.Amount)
    from EYR_SCHEDULE  t355  JOIN    AGR_EYR  t350
	 on t355.id_agr_eyr = t350.id_agr_eyr
              where

           t350.id_Agreement = t310. id_Agreement
      			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI1'
			and t350. ind_active = '1'), 0) as CLI1amount,


--CLi2
		nvl((select sum(t350. Rate)
			from AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI2'
			and t350. ind_active = '1'), 0) as Cli2,

--DATA
		nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'DATA'
			and t350.ind_active = '1'),0)
		as DATA,

--RAPP
		nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type  = 'RAPP'
			and t350.ind_active = '1'),0)
		as RAPP,


--RAPP_amount
	    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN  DBOANEE.AGR_EYR  t350
	        on t355.id_agr_eyr = t350.id_agr_eyr
            where
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'RAPP'
			and t350. ind_active = '1'), 0)
		as RAPPamount,


--RFAi
  		nvl((select sum(t350.Rate)
			from AGR_EYR t350
			where

      t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350.id_EYR_Type = 'RFAI'
			and t350.ind_active = '1'),0) as RFAi,

--RFA2
      nvl((select sum(t350.Rate)
			from AGR_EYR  t350
			where

       t350.id_Agreement = t310.id_agreement
			and t350. ind_Conditionnal = '0'
			and t350.id_EYR_Type = 'RFA2'
			and t350.ind_active = '1'),0) as RFA2,

--RFCC
	nvl((select max(t353.Rate)
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where
			t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFCC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'),0)
	as RFCC,


--BOSE (openning budget)
	  	nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where

			t340.id_agreement = t310.id_agreement
			and t340.id_Service_Type= 'BOSE'
			and t340.ind_active = '1'),0) AS BOSE,

--BOSE amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE  t340
			where

			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'BOSE'
			and t340. ind_active = '1'), 0)  AS BOSEamount,
--Code
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'CODE'
			and t340.ind_active = '1'),0) AS Code,
-------------------------------------------------------------------------
--DPHS_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'DPHS'
			and t340.ind_active = '1'),0) AS DPHS_Cost1,

--DPHS_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'DPHS'
			and t340.ind_active = '1'), 0) AS DPHS_Qty_Per_Store,

--DPHS_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'DPHS'
			and t340.ind_active = '1'), 0) AS DPHS_TotalQty,

--DPHS_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'DPHS'
			and t340.ind_active = '1'), 0) AS DPHS_Total_Amount,
-------------------------------------------------------------------------

--DPSC_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE   t340
			where

			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'DPSC'
			and t340.ind_active = '1'), 0) AS DPSC_Cost1,

--DPSC_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE    t340
			where

			t340. id_Agreement = t310. id_Agreement
			and t340. id_Service_Type = 'DPSC'
			and t340. ind_active = '1'), 0) AS DPSC_Qty_Per_Store,

--DPSC_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE  t340
			where

			t340. id_Agreement = t310. id_Agreement
			and t340. id_Service_Type = 'DPSC'
			and t340. ind_active = '1'), 0) AS DPSC_TotalQty,

--DPSC_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE  t340
			where

			t340. id_Agreement = t310. id_Agreement
			and t340. id_Service_Type = 'DPSC'
			and t340. ind_active = '1'), 0) AS DPSC_Total_Amount,
-------------------------------------------------------------------------

--NPAB
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE  t340
			where

			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'NPAB'
			and t340. ind_active = '1'), 0)  AS NPAB,

-------------------------------------------------------------------------

--PIHS_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PIHS'
			and t340.ind_active = '1'), 0) AS PIHS_Cost1,

--PIHS_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE  t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PIHS'
			and t340.ind_active = '1'), 0) AS PIHS_Qty_Per_Store,

--PIHS_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PIHS'
			and t340.ind_active = '1'), 0) AS PIHS_TotalQty,

--PIHS_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PIHS'
			and t340.ind_active = '1'), 0) AS PIHS_Total_Amount,

-------------------------------------------------------------------------

--PISC_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PISC'
			and t340.ind_active = '1'), 0) AS PISC_Cost1,

--PISC_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PISC'
			and t340.ind_active = '1'), 0) AS PISC_Qty_Per_Store,

--PISC_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PISC'
			and t340.ind_active = '1'), 0) AS PISC_TotalQtyO,

--PISC_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PISC'
			and t340.ind_active = '1'), 0) AS PISC_Total_Amount,


-------------------------------------------------------------------------

--PPHS_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPHS'
			and t340.ind_active = '1'), 0) AS PPHS_Cost1,

--PPHS_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPHS'
			and t340.ind_active = '1'), 0) AS PPHS_Qty_Per_Store,

--PPHS_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPHS'
			and t340.ind_active = '1'), 0) AS PPHS_TotalQty,

--PPHS_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPHS'
			and t340.ind_active = '1'), 0) AS PPHS_Total_Amount,

-------------------------------------------------------------------------

--PPSC_Billing_Cost_Per_Service PPSC
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPSC'
			and t340.ind_active = '1'), 0) AS PPSC_Cost1,

--PPSC_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPSC'
			and t340.ind_active = '1'), 0) AS PPSC_Qty_Per_Store,

--PPSC_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPSC'
			and t340.ind_active = '1'), 0) AS PPSC_TotalQty,

--PPSC_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPSC'
			and t340.ind_active = '1'), 0) AS PPSC_Total_Amount,

-------------------------------------------------------------------------

--PSHS_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSHS'
			and t340.ind_active = '1'), 0) AS PSHS_Cost1,

--PSHS_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSHS'
			and t340.ind_active = '1'), 0) AS PSHS_Qty_Per_Store,

--PSHS_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSHS'
			and t340.ind_active = '1'), 0) AS PSHS_TotalQty,

--PSHS_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSHS'
			and t340.ind_active = '1'), 0) AS PSHS_Total_Amount,

-------------------------------------------------------------------------

--Sibo
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
                                        and t340.Id_service_type = 'SIBO'
			and t340.ind_active = '1'), 0) AS Sibo,

-------------------------------------------------------------------------

--TGHS_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGHS'
			and t340.ind_active = '1'), 0) AS TGHS_Cost1,

--TGHS_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
	                            and t340.Id_service_type = 'TGHS'
			and t340.ind_active = '1'), 0) AS TGHS_Qty_Per_Store,

--TGHS_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGHS'
			and t340.ind_active = '1'), 0) AS TGHS_TotalQty,

--TGHS_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGHS'
			and t340.ind_active = '1'), 0) AS TGHS_Total_Amount,

-------------------------------------------------------------------------

--TGsc_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGSC'
			and t340.ind_active = '1'), 0) AS TGSC_Cost1,

--TGsc_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGSC'
			and t340.ind_active = '1'), 0) AS TGSC_Qty_Per_Store,

--TGsc_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGSC'
			and t340.ind_active = '1'), 0) AS TGSC_TotalQty,

--TGsc_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGSC'
			and t340.ind_active = '1'), 0) AS TGSC_Total_Amount,

-------------------------------------------------------------------------
--ZPHS_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE   t340
			where
			t340. id_Agreement = t310. id_Agreement
			and t340. id_Service_Type = 'ZPHS'
			and t340. ind_active = '1'), 0) AS ZPHS_Cost1,

--ZPHS_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE  t340
			where
			t340. id_Agreement = t310. id_Agreement
			and t340. id_Service_Type = 'ZPHS'
			and t340. ind_active = '1'), 0) AS ZPHS_Qty_Per_Store,

--ZPHS_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE   t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPHS'
			and t340.ind_active = '1'),0) AS ZPHS_TotalQty,

--ZPHS_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPHS'
			and t340.ind_active = '1'), 0) AS ZPHS_Total_Amount,
-------------------------------------------------------------------------

--ZPSC_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0) AS ZPSC_Cost1,

--ZPSC_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0) AS ZPSC_Qty_Per_Store,

--ZPSC_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0) AS ZPSC_TotalQty,

--ZPSC_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where
			t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0) AS ZPSC_Total_Amount,
-------------------------------------------------------------------------
--NRSi
		nvl((select sum(t350. Rate)
			from AGR_EYR  t350
			where

			t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'NRSi'
			and t350. ind_active = '1'), 0) as NRSi,

--EDI
		nvl((select sum(t350. Rate)
			from AGR_EYR  t350
			where

			t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDIW'
			and t350. ind_active = '1'), 0) as EDI,

--EDIWamount
	nvl((select sum(t355.Amount)
       from EYR_SCHEDULE  t355  JOIN    AGR_EYR  t350
	     on t355.id_agr_eyr=t350.id_agr_eyr
       Where

       t350.id_Agreement = t310.id_Agreement
			 and t350.ind_Conditionnal = '0'
			 and t350. id_EYR_Type = 'EDIW'
    	and t350. ind_active = '1'), 0) as EDIWamount,

--EDI2
		nvl((select sum(t350. Rate)
			from AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDI2'
			and t350. ind_active = '1'), 0) as EDI2,

--EDI2amount
	nvl((select sum(t355.Amount)
    from EYR_SCHEDULE  t355  JOIN    AGR_EYR  t350
	 on t355.id_agr_eyr = t350.id_agr_eyr
              where

           t350.id_Agreement = t310. id_Agreement
      			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDI2'
			and t350. ind_active = '1'), 0) as EDI2amount,


--SPI%
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'SPI%'
			and t350. ind_active = '1'), 0)
		as SPI,

--PGL1
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'PGL1'
			and t350.ind_active = '1'),0)
	as PGL1,

--PGL2
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where

			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'PGL2'
			and t350.ind_active = '1'),0)
	as PGL2,



 --RFAC
             nvl((select max(t353.Rate)
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where
			t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFAC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'),0)
        as RFAc,
infos

	from
		AGREEMENT  t310 inner join
		SUPPLIER  t040 on
		t310.id_supplier = t040. id_supplier

               left outer join AGR_PAYMENT  t320 on
		t310.id_agreement= t320.id_agreement
		and t320.id_Payment_Type = 'TERM'

            join dboanee.AGR_CONDITION t315 on
            t310.id_agreement = t315.id_agreement

            left join dboanee.negotiation_group  ng
            on t315.id_supplier=ng.id_supplier
            and substr(t315.id_negotiation_group, 1,3)=ng.id_negotiation_group

            left join dboanee.user_account ac
            on ng.id_user_account=ac.id_user_account

	where
	t310.id_agr_status   in ('WFS', 'SGN', 'CAN', 'INK')

order by N_AGREEMENT, ID_AGR_STATUS, ID_AGR_TYPE

) loop
pipe row (curr);
end loop;
else

for curr in
(
select distinct
		t310.N_AGREEMENT,
		t310.VERSION,
		t040.cod_utl_supplier as supplier,
		t040. Name as supplier_name,
	        t310. Condition,
  	nvl((select t356.text_Value
			from AGR_OPTION_VALUE  t356
			where
			t356.id_Agreement = t310.id_Agreement
			and t356.id_Option = 'EDRP'),'')
               as code_fiscal,
		ac.name as BUYER,
			t310. SHORT_CONDITION,
			t310. ID_AGR_STATUS,
			t310. ID_AGR_TYPE ,
			t310.NB_FISCAL,
                        t310.DT_Fiscal,
                        t310.NB_SERVICE,
                        t310.DT_SERVICE,


--Rba
  		nvl((select sum(t330.Rate)
		from AGR_DISCOUNT_TYPE  t330
		where
     	                t310.Year  = yr and
                        t330.id_Agreement = t310.id_agreement
			and t330.id_Inv_Discount_Type = 'RBA'
			and t330.ind_active = '1'),0) as Rba

--Rba_remark
        ,nvl((select t330.Remark
	from DBOANEE.AGR_DISCOUNT_TYPE  t330
	 where   t310.Year = yr and
            t330.id_Agreement = t310.id_agreement
	        and t330.id_Inv_Discount_Type = 'RBA'
	        and t330.ind_active = '1'),0)
		as Rba_remark

--Rpr
  		, nvl((select sum(t330.Rate)
			from AGR_DISCOUNT_TYPE t330
			where
                        t310.Year  = yr and
                        t330.Id_agreement = t310.id_agreement
			and t330.ID_INV_DISCOUNT_TYPE = 'RPR'
			and t330.ind_active = '1'),0) as Rpr,
-------------------------------------------------------------------------
			nvl(t320.Delay,0) as DelayInDays,
		 t310.TurnOver_Forecast as CA_total,
-------------------------------------------------------------------------
--CEGA
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CEGA'
			and t350. ind_active = '1'), 0)
		as CEGA,

--CLi1
		nvl((select sum(t350. Rate)
			from AGR_EYR   t350
			where
			 t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI1'
			and t350. ind_active = '1'), 0) as Cli1,

--Cli1_amount
	nvl((select sum(t355.Amount)
    from EYR_SCHEDULE  t355  JOIN    AGR_EYR  t350
	 on t355.id_agr_eyr = t350.id_agr_eyr
              where
			t310.Year  = yr and
			t350.id_Agreement = t310. id_Agreement
      			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI1'
			and t350. ind_active = '1'), 0) as CLI1amount,


--CLi2
		nvl((select sum(t350. Rate)
			from AGR_EYR   t350
			where
			 t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI2'
			and t350. ind_active = '1'), 0) as Cli2,

--DATA
		nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where t310.Year = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'DATA'
			and t350.ind_active = '1'),0)
		as DATA,

--RAPP
		nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where t310.Year = yr and
			t350.id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type  = 'RAPP'
			and t350.ind_active = '1'),0)
		as RAPP,


--RAPP_amount
	    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN  DBOANEE.AGR_EYR  t350
	        on t355.id_agr_eyr = t350.id_agr_eyr
			where
			t310.Year = yr
			and t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'RAPP'
			and t350. ind_active = '1'), 0)
		as RAPPamount,


--RFAi
  		nvl((select sum(t350.Rate)
			from AGR_EYR t350
			where
     	                t310.Year  = yr and
     	                t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350.id_EYR_Type = 'RFAI'
			and t350.ind_active = '1'),0) as RFAi,

--RFA2
      nvl((select sum(t350.Rate)
			from AGR_EYR  t350
			where
     	                t310.Year  = yr
     	                and t350.id_Agreement = t310.id_agreement
			and t350. ind_Conditionnal = '0'
			and t350.id_EYR_Type = 'RFA2'
			and t350.ind_active = '1'),0) as RFA2,

--RFCC
	nvl((select max(t353.Rate)
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where t310.Year = yr
			and t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFCC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'),0)
	as RFCC,


--BOSE (openning budget)
	  	nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where
			t310.Year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.id_Service_Type= 'BOSE'
			and t340.ind_active = '1'),0) AS BOSE,

--BOSE amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE  t340
			where
			t310.Year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'BOSE'
			and t340. ind_active = '1'), 0)  AS BOSEamount,

--Code
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'CODE'
			and t340.ind_active = '1'),0) AS Code,

-------------------------------------------------------------------------
--DPHS_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'DPHS'
			and t340.ind_active = '1'),0) AS DPHS_Cost1,

--DPHS_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'DPHS'
			and t340.ind_active = '1'), 0) AS DPHS_Qty_Per_Store,

--DPHS_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'DPHS'
			and t340.ind_active = '1'), 0) AS DPHS_TotalQty,

--DPHS_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'DPHS'
			and t340.ind_active = '1'), 0) AS DPHS_Total_Amount,

-------------------------------------------------------------------------
--DPSC_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE   t340
			where
			 t310.Year  = yr and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'DPSC'
			and t340.ind_active = '1'), 0) AS DPSC_Cost1,

--DPSC_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE    t340
			where
			 t310.Year  = yr and
			t340. id_Agreement = t310. id_Agreement
			and t340. id_Service_Type = 'DPSC'
			and t340. ind_active = '1'), 0) AS DPSC_Qty_Per_Store,

--DPSC_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE  t340
			where
			 t310.Year  = yr and
			t340. id_Agreement = t310. id_Agreement
			and t340. id_Service_Type = 'DPSC'
			and t340. ind_active = '1'), 0) AS DPSC_TotalQty,

--DPSC_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE  t340
			where
			 t310.Year  = yr and
			t340. id_Agreement = t310. id_Agreement
			and t340. id_Service_Type = 'DPSC'
			and t340. ind_active = '1'), 0) AS DPSC_Total_Amount,
-------------------------------------------------------------------------

--new position
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE  t340
			where
			t310.Year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'NPAB'
			and t340. ind_active = '1'), 0)  AS NPAB,
-------------------------------------------------------------------------

--PIHS_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PIHS'
			and t340.ind_active = '1'), 0) AS PIHS_Cost1,

--PIHS_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE  t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PIHS'
			and t340.ind_active = '1'), 0) AS PIHS_Qty_Per_Store,

--PIHS_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PIHS'
			and t340.ind_active = '1'), 0) AS PIHS_TotalQty,

--PIHS_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PIHS'
			and t340.ind_active = '1'), 0) AS PIHS_Total_Amount,
------------------------------------------------------------------------

--PISC_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PISC'
			and t340.ind_active = '1'), 0) AS PISC_Cost1,

--PISC_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PISC'
			and t340.ind_active = '1'), 0) AS PISC_Qty_Per_Store,

--PISC_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PISC'
			and t340.ind_active = '1'),0) AS PISC_TotalQtyO,

--PISC_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PISC'
			and t340.ind_active = '1'), 0) AS PISC_Total_Amount,

------------------------------------------------------------------------

--PPHS_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPHS'
			and t340.ind_active = '1'), 0) AS PPHS_Cost1,

--PPHS_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPHS'
			and t340.ind_active = '1'), 0) AS PPHS_Qty_Per_Store,

--PPHS_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPHS'
			and t340.ind_active = '1'), 0) AS PPHS_TotalQty,

--PPHS_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPHS'
			and t340.ind_active = '1'), 0) AS PPHS_Total_Amount,

------------------------------------------------------------------------

--PPSC_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPSC'
			and t340.ind_active = '1'), 0) AS PPSC_Cost1,

--PPSC_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPSC'
			and t340.ind_active = '1'), 0) AS PPSC_Qty_Per_Store,

--PPSC_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPSC'
			and t340.ind_active = '1'), 0) AS PPSC_TotalQty,

--PPSC_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPSC'
			and t340.ind_active = '1'), 0) AS PPSC_Total_Amount,

------------------------------------------------------------------------

--PSHS_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSHS'
			and t340.ind_active = '1'), 0) AS PSHS_Cost1,

--PSHS_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSHS'
			and t340.ind_active = '1'), 0) AS PSHS_Qty_Per_Store,

--PSHS_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSHS'
			and t340.ind_active = '1'), 0) AS PSHS_TotalQty,

--PSHS_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSHS'
			and t340.ind_active = '1'), 0) AS PSHS_Total_Amount,

------------------------------------------------------------------------
--Sibo
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
                                        and t340.Id_service_type = 'SIBO'
			and t340.ind_active = '1'), 0) AS Sibo,

------------------------------------------------------------------------

--TGHS_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGHS'
			and t340.ind_active = '1'), 0) AS TGHS_Cost1,

--TGHS_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
	                            and t340.Id_service_type = 'TGHS'
			and t340.ind_active = '1'), 0) AS TGHS_Qty_Per_Store,

--TGHS_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGHS'
			and t340.ind_active = '1'), 0) AS TGHS_TotalQty,

--TGHS_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGHS'
			and t340.ind_active = '1'), 0) AS TGHS_Total_Amount,

------------------------------------------------------------------------
--TGsc_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGSC'
			and t340.ind_active = '1'), 0) AS TGSC_Cost1,

--TGsc_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGSC'
			and t340.ind_active = '1'), 0) AS TGSC_Qty_Per_Store,

--TGsc_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGSC'
			and t340.ind_active = '1'), 0) AS TGSC_TotalQty,

--TGsc_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGSC'
			and t340.ind_active = '1'), 0) AS TGSC_Total_Amount,

------------------------------------------------------------------------
--ZPHS_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE   t340
			where t310.year  = yr and
			t340. id_Agreement = t310. id_Agreement
			and t340. id_Service_Type = 'ZPHS'
			and t340. ind_active = '1'), 0) AS ZPHS_Cost1,

--ZPHS_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE  t340
			where t310.year  = yr and
			t340. id_Agreement = t310. id_Agreement
			and t340. id_Service_Type = 'ZPHS'
			and t340. ind_active = '1'), 0) AS ZPHS_Qty_Per_Store,

--ZPHS_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE   t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPHS'
			and t340.ind_active = '1'),0) AS ZPHS_TotalQty,

--ZPHS_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPHS'
			and t340.ind_active = '1'), 0) AS ZPHS_Total_Amount,

------------------------------------------------------------------------
--ZPSC_Billing_Cost_Per_Service
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0) AS ZPSC_Cost1,

--ZPSC_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0) AS ZPSC_Qty_Per_Store,

--ZPSC_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0) AS ZPSC_TotalQty,

--ZPSC_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0) AS ZPSC_Total_Amount,
------------------------------------------------------------------------

--NRSi
		nvl((select sum(t350. Rate)
			from AGR_EYR  t350
			where
			t310.Year  = yr
			and t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'NRSi'
			and t350. ind_active = '1'), 0) as NRSi,

--EDI
		nvl((select sum(t350. Rate)
			from AGR_EYR  t350
			where
			t310.Year  = yr
			and t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDIW'
			and t350. ind_active = '1'), 0) as EDI,

--EDIWamount
	nvl((select sum(t355.Amount)
       from EYR_SCHEDULE  t355  JOIN    AGR_EYR  t350
	     on t355.id_agr_eyr=t350.id_agr_eyr
                        Where
			t310.Year  = yr
			and t350.id_Agreement = t310.id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDIW'
    	and t350. ind_active = '1'), 0) as EDIWamount,

--EDI2
		nvl((select sum(t350. Rate)
			from AGR_EYR   t350
			where
			t310.Year  = yr
			and t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDI2'
			and t350. ind_active = '1'), 0) as EDI2,

--EDI2amount
	nvl((select sum(t355.Amount)
    from EYR_SCHEDULE  t355  JOIN    AGR_EYR  t350
	 on t355.id_agr_eyr = t350.id_agr_eyr
              where
			t310.Year  = yr
			and t350.id_Agreement = t310. id_Agreement
      			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDI2'
			and t350. ind_active = '1'), 0) as EDI2amount,

--SPI%
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'SPI%'
			and t350. ind_active = '1'), 0)
		as SPI,

--PGL1
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'PGL1'
			and t350.ind_active = '1'),0)
	as PGL1,

--PGL2
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'PGL2'
			and t350.ind_active = '1'),0)
	as PGL2,


 --RFAC
             nvl((select max(t353.Rate)
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where t310.Year  = yr
			and t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFAC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'),0)
        as RFAc,
infos

	from
		AGREEMENT  t310 inner join
		SUPPLIER  t040 on
		t310.id_supplier = t040. id_supplier

               left outer join AGR_PAYMENT  t320 on
		t310.id_agreement= t320.id_agreement
		and t320.id_Payment_Type = 'TERM'

            join dboanee.AGR_CONDITION t315 on
            t310.id_agreement = t315.id_agreement

            left join dboanee.negotiation_group  ng
            on t315.id_supplier=ng.id_supplier
            and substr(t315.id_negotiation_group, 1,3)=ng.id_negotiation_group

            left join dboanee.user_account ac
            on ng.id_user_account=ac.id_user_account

	where
        t310.year  = yr

	and t310.id_agr_status   in ('WFS', 'SGN', 'CAN', 'INK')
        and t310.version= (select max(version)
                   from dboanee.agreement agr
                  where t310.n_agreement=agr.n_agreement
                   and agr.id_agr_status in ('SGN', 'CAN', 'WFS', 'INK')
                   and agr.year=yr)

order by N_AGREEMENT, ID_AGR_STATUS, ID_AGR_TYPE

) loop
pipe row (curr);
end loop;
end if;
end funContractWTSFCDG;
end prdContractWTSFCDG;
/

