create package body      prdContractBose is
function funContractBose
(yr number,
spl number )
return tblContrBose
pipelined
is
begin


for curr in
(
select
year1 as Year,
nvl(bose.buyer,ca.buyer) as Buyer,
bose.supplier as Supplier,
nvl (bose.condition,ca.condition) as GroupSection,
nvl(bose.nb_fiscal, ca.nb_fiscal) as Fiscalnumber,
bose.section as Section,
bose.t410TotalAmountInvNoVAT as BoseInvoiced,
bose.id_inv_request  as InvoiceNumber,
bose.dt_invoice,
bose.ID_ACC_UNIT as StoreInvoiced,
bose.id_store as StoreTO,
ca.AmountNotVAT as Turnover,
bose.id_company as Society,
nvl(bose.id_service_type,ca.id_service_type) as ServiceType,
nvl(bose.ID_AGR_STATUS,ca.ID_AGR_STATUS) as AgreementStatus,
bose.remark,
nvl(bose.Infos,ca.Infos) as Infos

from
(select
invoice.id_supplier,
t040.cod_utl_supplier as supplier,
invoice.section,
invoice.id_inv_type,
invoice.ta,
invoice.t410TotalAmountInvNoVAT,
invoice.Year,
invoice.id_inv_request ,
invoice.dt_invoice,
invoice.IND_CANCELLED,
invoice.Status,
invoice.ID_ACC_UNIT,
invoice.REMARK,
invoice.id_store,
invoice.ID_COMPANY,
fiscalnumber.year1,
fiscalnumber.nb_fiscal,
fiscalnumber.CONDITION,
fiscalnumber.ID_AGR_STATUS,
fiscalnumber.BUYER,
fiscalnumber.id_service_type,
fiscalnumber.total_amount,
fiscalnumber.Infos

 from

(
select
t410.id_supplier,
t410.id_negotiation_group as section,
t410.id_inv_type,
t410.total_amount_ht_sc as ta,
(t410.total_amount_ht_sc)/d.stores as t410TotalAmountInvNoVAT,
t410.Year,
t410.id_inv_request ,
t410.dt_invoice,
t410.IND_CANCELLED,
t410.Status,
t410.ID_ACC_UNIT,
t410.REMARK,
t430.id_store,
 t420.ID_COMPANY

from dboanee.INV_REQUEST_HEAD   t410
join dboanee.INV_REQUEST_STORE  t430
on t410.id_inv_request = t430.id_inv_request

join dboanee.INV_REQUEST_LINE   t420
on t410.id_inv_request = t420.id_inv_request
and t420.ID_SERVICE_TYPE = 'BOSE'

join
(select t410.id_inv_request,
count(distinct t430.ID_STORE) as stores
from
dboanee.INV_REQUEST_STORE t430,
dboanee.INV_REQUEST_HEAD t410
where t410.id_inv_request = t430.id_inv_request
group by t410.id_inv_request) d
on t410.id_inv_request = d.id_inv_request
and t410.id_inv_type = 'E'
) invoice

join
(select distinct
year1,
t310.nb_fiscal,
t310.id_supplier as supplier ,
t310.CONDITION,
t315.id_negotiation_group  as section,
t310.ID_AGR_STATUS,
ac.name as BUYER,
t340.id_service_type,
t340.total_amount,
t310.Infos

from dboanee.agreement t310
 join dboanee.agr_condition t315
 on ( t310.id_agreement = t315.id_agreement
 and t310.id_supplier = t315.id_supplier )

left join
dboanee.agr_service t340
 on (t310.id_agreement = t340.id_agreement
and t340.id_service_type = 'BOSE')

left	join
 (select
 distinct  max(t310.Year) as year1,
 t310.id_supplier as sup,
 t315.id_negotiation_group as sec
 from dboanee.agreement t310
 join  dboanee.agr_condition t315
 on
 t310.id_agreement = t315.id_agreement and
 t310.id_supplier = t315.id_supplier
 group by  t310.id_supplier, t315.id_negotiation_group
 ) m
 on   m.sup = t310.id_supplier
 and m.sec = t315.id_negotiation_group

  left join dboanee.negotiation_group  ng
on t315.id_supplier=ng.id_supplier
and substr(t315.id_negotiation_group, 1,3)=ng.id_negotiation_group
left join dboanee.user_account ac
on ng.id_user_account=ac.id_user_account


 where
 t310.Year = m.year1
 and m.year1 > 2007
 and t310.nb_fiscal not like '%.%'
 and t310.id_agr_type in('STD', 'VIP')
 and t310.id_agr_status in ('SGN', 'CAN', 'WFS', 'INK')

 ) fiscalnumber

on
invoice.id_supplier = fiscalnumber.supplier
 and invoice.section = fiscalnumber.section

join dboanee.supplier t040
on invoice.id_supplier=t040.id_supplier
) bose

full join

(SELECT
 fn.nb_fiscal,
 fn.total_amount,
 fn.Condition,
 fn.ID_AGR_STATUS,
  fn.buyer,
 fn.id_service_type,
 Infos,
 t730.id_negotiation_group,
 t730.id_Store,
 t040.cod_utl_supplier as supplier,
 round(Sum(TO_AMOUNT_HT), 2) as AmountNotVAT

from DBOANEE.NEGO_GROUP_PURCHASES t730 join

(select distinct
year1,
t310.nb_fiscal,
t310.id_supplier as sup,
t310.Condition,
t315.id_negotiation_group as sec,
t310.ID_AGR_STATUS,
ac.name as BUYER,
t340.id_service_type,
t340.total_amount,
t310.Infos
from dboanee.agreement t310 join dboanee.agr_condition t315
	on (t310.id_agreement = t315.id_agreement and
	t310.id_supplier = t315.id_supplier)

left join
dboanee.agr_service t340
on (t310.id_agreement = t340.id_agreement
and t340.id_service_type = 'BOSE')

left	join
 (select distinct
 max(t310.Year) as year1,
 t310.id_supplier as sup,
  t315.id_negotiation_group as sec
 from dboanee.agreement t310
 join dboanee.agr_condition t315
 on  t310.id_agreement = t315.id_agreement and
 t310.id_supplier = t315.id_supplier
 group by  t310.id_supplier, t315.id_negotiation_group
 ) m
 on   m.sup = t310.id_supplier and m.sec = t315.id_negotiation_group

  left join dboanee.negotiation_group  ng
on t315.id_supplier=ng.id_supplier
and substr(t315.id_negotiation_group, 1,3)=ng.id_negotiation_group
left join dboanee.user_account ac
on ng.id_user_account=ac.id_user_account

 where
 t310.Year = m.year1
 and m.year1 > 2007
 and t310.nb_fiscal not like '%.%'
 and t310.id_agr_type = 'STD'
 and t310.id_agr_status in ('SGN', 'CAN', 'WFS', 'INK')

 ) fn

 on (fn.sup = t730.id_supplier and fn.sec = t730.id_negotiation_group)

 join dboanee.supplier t040
 on t730.id_supplier=t040.id_supplier

 where Year = yr  and t040.cod_utl_supplier < 8000

 Group by t730.id_negotiation_group, t730.id_Store, t040.cod_utl_supplier,
fn.nb_fiscal,fn.total_amount,fn.Condition,
 fn.ID_AGR_STATUS, fn.buyer,fn.id_service_type,
 Infos
) ca

 on (ca.id_negotiation_group=bose.section
 and ca.supplier = bose.supplier
 and bose.id_store = ca.id_store)

 where 1=1
	and 	bose.id_supplier = spl
) loop
pipe row (curr);
end loop;


end funContractBose;
end prdContractBose;
/

