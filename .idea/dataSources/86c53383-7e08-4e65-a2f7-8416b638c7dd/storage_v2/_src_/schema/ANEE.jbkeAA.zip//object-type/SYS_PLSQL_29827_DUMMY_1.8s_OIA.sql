create type        SYS_PLSQL_29827_DUMMY_1 as table of number;
/

