create package body      prdContract7 is
function funContract7
(yr number )
return tblContr7
pipelined
is
begin

for curr in
(
select
    t310.N_AGREEMENT,
    t310.VERSION,
    t040.cod_utl_supplier as supplier,
    t040. Name as supplier_name,
    ac.name as BUYER,
    t310. Condition,
    nvl((select t356.text_Value
			from dboanee.AGR_OPTION_VALUE  t356
			where
			t356.id_Agreement = t310.id_Agreement
			and t356.id_Option = 'EDRP' and t356.ind_active = '0'),'')
    as code_fiscal,
    t310. SHORT_CONDITION,
    t310. ID_AGR_STATUS,
    t310.NB_FISCAL,
    t310.DT_Fiscal,
    t315.id_negotiation_group,
    nvl(t320.Delay,0)  as DelayInDays,
    t310.TurnOver_Forecast as CA_total,
    t315.to_amount as CA_Nego_par_Seg,

--Rba
nvl((select sum(t330.Rate)
		    from DBOANEE.AGR_DISCOUNT_TYPE  t330
		    where   t310.Year  = yr and
            t330.id_Agreement = t310.id_agreement
	        and t330.id_Inv_Discount_Type = 'RBA'
	        and t330.ind_active = '1'),0) as RBA,
--Rpr
nvl((select sum(t330.Rate)
			from DBOANEE.AGR_DISCOUNT_TYPE t330
			where t310.Year  = yr
			and t330.Id_agreement = t310.id_agreement
			and t330.ID_INV_DISCOUNT_TYPE = 'RPR'
			and t330.ind_active = '1'),0) as RPR,

--RFAi
        nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where
            t310.Year  = yr and
            t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350.id_EYR_Type = 'RFAI'
			and t350.ind_active = '1'),0)
		as RFAi,
--RFA2
        nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR  t350
			where t310.Year  = yr and
            t350.id_Agreement = t310.id_agreement
			and t350. ind_Conditionnal = '0'
			and t350.id_EYR_Type = 'RFA2'
			and t350.ind_active = '1'),0)
		as RFA2,

--CLi1
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI1'
			and t350. ind_active = '1'), 0)
		as Cli1,

--Cli1_amount

	  nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN    DBOANEE.AGR_EYR  t350
	        on t355.id_agr_eyr=t350.id_agr_eyr
            Where t310.Year  = yr and
            t350.id_Agreement = t310.id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI1'
    	    and t350. ind_active = '1'), 0)
		as Cli1_amount,


--DATA
		nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'DATA'
			and t350.ind_active = '1'),0)
		as DATA,

--CLi2
		nvl((select sum(t350. Rate)
			from AGR_EYR   t350
			where
			t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI2'
			and t350. ind_active = '1'), 0)
		as Cli2,

--EDI
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR  t350
			where t310.Year  = yr and
			t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDIW'
			and t350. ind_active = '1'), 0)
		as EDI,

--EDIWamount
	    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN    DBOANEE.AGR_EYR  t350
	        on t355.id_agr_eyr=t350.id_agr_eyr
            Where t310.Year  = yr and
            t350.id_Agreement = t310.id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDIW'
    	    and t350. ind_active = '1'), 0)
		as EDIWamount,

--EDI2
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDI2'
			and t350. ind_active = '1'), 0)
		as EDI2,

--EDI2amount
	    nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN  DBOANEE.AGR_EYR  t350
	        on t355.id_agr_eyr = t350.id_agr_eyr
            where  t310.Year  = yr and
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDI2'
			and t350. ind_active = '1'), 0)
		as EDI2amount,

--RFAc
nvl((select max(t353.Rate)
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where t310.Year  = yr
			and t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFAC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'),0)
        as RFAc,


--CEGA
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CEGA'
			and t350.ind_active = '1'),0)
	as CEGA,

--SPi%
		nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'SPI%'
			and t350.ind_active = '1'),0)
	as SPi,

--NRSi
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR  t350
			where t310.Year  = yr and
			t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'NRSI'
			and t350. ind_active = '1'), 0)
	as NRSi,


--Bud_ouv (BOSE)
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from DBOANEE.AGR_SERVICE t340
			where
			t310.year = yr  and
			t340.id_agreement = t310.id_agreement
			and t340.id_Service_Type= 'BOSE'
			and t340.ind_active = '1'),0)
	AS BOSE,


--BOSEamount
		nvl((select sum(t340.Total_Amount)
			from DBOANEE.AGR_SERVICE  t340
			where t310.Year  = yr and
			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'BOSE'
			and t340. ind_active = '1'), 0)
		AS BOSEamount,


--RMDL

           nvl((select sum(t340. BILLING_COST_PER_SERVICE)
			from DBOANEE.AGR_SERVICE  t340
			where t310.Year  = yr and
			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'RMDL'
			and t340. ind_active = '1'),0)
		AS RMDL,

--New_pos
		nvl((select sum(t340.Total_Amount)
			from DBOANEE.AGR_SERVICE  t340
			where t310.Year  = yr and
			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'NPAB'
			and t340. ind_active = '1'), 0)
		AS New_pos,


--Code
		nvl((select sum(t340.Total_Amount)
			from dboanee.AGR_SERVICE t340
			where t310.Year  = yr and
			t340. id_Agreement = t310. id_Agreement
	     	and t340.COOPERATION_TYPE = 'B'
			and t340.id_Service_Type = 'CODE'
			and t340.ind_active = '1'),0)
		AS Code,

--Sibo
		nvl((select sum(t340.Total_Amount)
			from dboanee.AGR_SERVICE t340
			where t310.Year  = yr and
			t340. id_Agreement = t310. id_Agreement
	     	and t340.COOPERATION_TYPE = 'B'
			and t340.id_Service_Type = 'SIBO'
			and t340.ind_active = '1'),0)
               AS Sibo,


--RAPP
	nvl((select sum(t350.Rate)
			from DBOANEE.AGR_EYR t350
			where t310.Year  = yr and
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type  = 'RAPP'
			and t350.ind_active = '1'),0)
	as RAPP,

--RAPP_amount
	 nvl((select sum(t355.Amount)
            from DBOANEE.EYR_SCHEDULE  t355  JOIN  DBOANEE.AGR_EYR  t350
	        on t355.id_agr_eyr = t350.id_agr_eyr
            where  t310.Year  = yr and
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'RAPP'
			and t350. ind_active = '1'), 0)
		as RAPP_amount,

--PGl1
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'PGL1'
			and t350.ind_active = '1'),0)
	as PGl1,

--PGL2
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'PGL2'
			and t350.ind_active = '1'),0)
	as PGL2,

--RFCC
	nvl((select sum(t350. Rate)
			from DBOANEE.AGR_EYR   t350
			where
			 t310.Year  = yr and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'RFCC'
			and t350.ind_active = '1'),0)
	as RFCC,



--Degust_Cost1
		nvl((select sum(t340.BILLING_COST_PER_SERVICE)
			from dboanee.AGR_SERVICE t340
			where t310.Year  = yr and
			t340. id_Agreement = t310. id_Agreement
	     	and t340.COOPERATION_TYPE = 'B'
			and t340.id_Service_Type  = 'DPSC'
			and t340.ind_active  = '1'),0)
    	AS Degust_Cost1,

--Degust_QtyPerStore
		nvl((select sum(t340.Qty_Per_Store)
			from dboanee.AGR_SERVICE t340
			where t310.Year  = yr and
			t340. id_Agreement = t310. id_Agreement
	     	and t340.COOPERATION_TYPE = 'B'
			and t340.id_Service_Type  = 'DPSC'
			and t340.ind_active  = '1'),0)
			AS Degust_QtyPerStore,

--Degust_TotalQty
		nvl((select sum(t340.Total_Qty)
			from dboanee.AGR_SERVICE t340
			where t310.Year  = yr and
			t340. id_Agreement = t310. id_Agreement
	     	and t340.COOPERATION_TYPE = 'B'
			and t340.id_Service_Type  = 'DPSC'
			and t340.ind_active  = '1'),0)
			AS Degust_TotalQty,

--Degust_TotalAmount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE  t340
			where
			 t310.Year  = yr and
			t340. id_Agreement = t310. id_Agreement
			and t340. id_Service_Type = 'DPSC'
			and t340. ind_active = '1'), 0)
			AS Degust_TotalAmount,

--TGSC_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGSC'
			and t340.ind_active = '1'), 0) AS TGSC_Cost1,

--TGsc_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGSC'
			and t340.ind_active = '1'), 0)
          AS TGSC_Qty_Per_Store,

--TGsc_Total_Qty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGSC'
			and t340.ind_active = '1'), 0)
          AS TGSC_TotalQty,

--TGsc_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGSC'
			and t340.ind_active = '1'), 0)
        AS TGSC_Total_Amount,

--StRay_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PISC'
			and t340.ind_active = '1'), 0) AS StRay_Cost1,

--StRay_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PISC'
			and t340.ind_active = '1'), 0) AS StRay_Qty_Per_Store,

--StRay_TotalQtyO
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PISC'
			and t340.ind_active = '1'),0) AS StRay_TotalQtyO,

--StRay_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PISC'
			and t340.ind_active = '1'), 0) AS StRay_Total_Amount,

--PONTON_Cost1,
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPSC'
			and t340.ind_active = '1'), 0) AS PONTON_Cost1,

--PONTON_Qty_Per_Store,
	nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPSC'
			and t340.ind_active = '1'), 0)
	AS PONTON_Qty_Per_Store,

--PONTON_TotalQty,
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPSC'
			and t340.ind_active = '1'), 0) AS PONTON_TotalQty,

--PONTON_Total_Amount,
	nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PPSC'
			and t340.ind_active = '1'), 0)
	AS PONTON_Total_Amount,


--Placement_special_Cost1
	nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSSC'
			and t340.ind_active = '1'), 0)
	AS PSSC_Cost1,

--Placement_special_QtyPerStore
	nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSSC'
			and t340.ind_active = '1'), 0)
	AS PSSC_QtyPerStore,

--Placement_special_TotalQty
	nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSSC'
			and t340.ind_active = '1'), 0)
	AS PSSC_TotalQty,

--Placement_special_TotalAmount
	nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'PSSC'
			and t340.ind_active = '1'), 0)
	AS PSSC_TotalAmount,

--Plato_Cost1
		nvl((select sum(t340.Billing_Cost_Per_Service)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0) AS Plato_Cost1,

--Plato_Qty_Per_Store
		nvl((select sum(t340.Qty_Per_Store)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0) AS Plato_Qty_Per_Store,

--Plato_TotalQty
		nvl((select sum(t340.Total_Qty)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0) AS Plato_TotalQty,

--Plato_Total_Amount
		nvl((select sum(t340.Total_Amount)
			from AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'ZPSC'
			and t340.ind_active = '1'), 0) AS Plato_Total_Amount,

--TGHS_Cost1
	nvl((select sum(t340.Billing_Cost_Per_Service)
			from dboanee.AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type = 'TGHS'
			and t340.ind_active = '1'), 0)
	AS TGHS_Cost1,

--TGHS_QtyPerStore
	nvl((select sum(t340.Qty_Per_Store)
			from dboanee.AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type= 'TGHS'
			and t340.ind_active = '1'),0)
	AS TGHS_QtyPerStore,

--TGHS_TotalQty
	nvl((select sum(t340.Total_Qty)
			from dboanee.AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
			and t340.Id_service_type= 'TGHS'
			and t340.ind_active = '1'),0)
	AS TGHS_TotalQty,

--TGHS_TotalAmount
	nvl((select sum(t340.Total_Amount)
			from dboanee.AGR_SERVICE t340
			where t310.year  = yr
			and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'TGHS'
      and t340.ind_active = '1'),0)
  AS TGHS_TotalAmount,

--PIHS_Cost1
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from dboanee.AGR_SERVICE t340
      where t310.year  = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PIHS'
      and t340.ind_active = '1'),0)  AS PIHS_Cost1,

--PIHS_Qty_Per_Store
    nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE  t340
      where t310.year  = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PIHS'
      and t340.ind_active = '1'), 0) AS PIHS_Qty_Per_Store,

--PIHS_Total_Qty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where t310.year  = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PIHS'
      and t340.ind_active = '1'), 0) AS PIHS_TotalQty,

--PIHS_Total_Amount
    nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where t310.year  = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PIHS'
      and t340.ind_active = '1'), 0) AS PIHS_Total_Amount,


--DPHS_Cost1,
    nvl((select sum(t340.Billing_Cost_Per_Service)
      from AGR_SERVICE t340
      where t310.year  = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'DPHS'
      and t340.ind_active = '1'),0) AS DPHS_Cost1,

--DPHS_Qty_Per_Store
    nvl((select sum(t340.Qty_Per_Store)
      from AGR_SERVICE t340
      where t310.year  = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'DPHS'
      and t340.ind_active = '1'), 0) AS DPHS_Qty_Per_Store,

--DPHS_Total_Qty
    nvl((select sum(t340.Total_Qty)
      from AGR_SERVICE t340
      where t310.year  = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'DPHS'
      and t340.ind_active = '1'), 0) AS DPHS_TotalQty,

--DPHS_Total_Amount
    nvl((select sum(t340.Total_Amount)
      from AGR_SERVICE t340
      where t310.year  = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'DPHS'
      and t340.ind_active = '1'), 0) AS DPHS_Total_Amount,


--PSHS_Cost1
  nvl((select sum(t340.Billing_Cost_Per_Service)
      from dboanee.AGR_SERVICE t340
      where t310.year  = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type = 'PSHS'
      and t340.ind_active = '1'), 0)
    AS PSHS_Cost1,

--PSHS_QtyPerStore
  nvl((select sum(t340.Qty_Per_Store)
      from dboanee.AGR_SERVICE t340
      where t310.year  = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'PSHS'
      and t340.ind_active = '1'),0)
  AS PSHS_QtyPerStore,

--PSHS_TotalQty
  nvl((select sum(t340.Total_Qty)
      from dboanee.AGR_SERVICE t340
      where t310.year  = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'PSHS'
      and t340.ind_active = '1'),0)
  AS PSHS_TotalQty,

--PSHS_TotalAmount
  nvl((select sum(t340.Total_Amount)
      from dboanee.AGR_SERVICE t340
      where t310.year  = yr
      and t340.id_agreement = t310.id_agreement
      and t340.Id_service_type= 'PSHS'
      and t340.ind_active = '1'),0)
  AS PSHS_TotalAmount,
    Infos

  from
    DBOANEE.AGREEMENT  t310 inner join
    DBOANEE.SUPPLIER  t040 on
    t310.id_supplier = t040. id_supplier

               left outer join DBOANEE.AGR_PAYMENT  t320 on
    t310.id_agreement= t320.id_agreement
    and t320.id_Payment_Type = 'TERM'

               join dboanee.AGR_CONDITION t315 on
               t310.id_agreement = t315.id_agreement

            left join dboanee.negotiation_group  ng
        on t315.id_supplier=ng.id_supplier
        and substr(t315.id_negotiation_group, 1,3)=ng.id_negotiation_group

        left join dboanee.user_account ac
        on ng.id_user_account=ac.id_user_account

  where

        t310.year  = yr

  and t310.id_agr_status  in ('NTG', 'NDM', 'NRA')
      /*  and t310.version= (select max(version)
                   from dboanee.agreement agr
                  where t310.n_agreement=agr.n_agreement
                   and agr.id_agr_status in ('NTG', 'NDM', 'NRA')
                   and agr.year= yr)*/
) loop
pipe row (curr);
end loop;

end funContract7;
end prdContract7;
/

