create package      prdContractWTSF2   is

type rowContrWTSF2 is record(
N_AGREEMENT     dboanee.agreement.N_AGREEMENT%TYPE,
VERSION         dboanee.agreement.VERSION%TYPE,
supplier        dboanee.supplier.cod_utl_supplier%TYPE,
supplier_name   dboanee.supplier.name%TYPE,
BUYER           dboanee.user_account.name%TYPE,
Condition       dboanee.agreement.Condition%TYPE,
code_fiscal     dboanee.AGR_OPTION_VALUE.text_value%TYPE,
SHORT_CONDITION dboanee.agreement.SHORT_CONDITION%TYPE,
ID_AGR_STATUS   dboanee.agreement.ID_AGR_STATUS%TYPE,
ID_AGR_TYPE     dboanee.agreement.ID_AGR_TYPE%TYPE,
NB_FISCAL       dboanee.agreement.NB_FISCAL%TYPE,
DT_Fiscal       dboanee.agreement.DT_Fiscal%TYPE ,
NB_SERVICE      dboanee.agreement.NB_SERVICE%TYPE,
DT_SERVICE      dboanee.agreement.DT_SERVICE%TYPE ,
Rba             number,
RBA_remark      DBOANEE.AGR_DISCOUNT_TYPE.remark%TYPE,
Rpr             number,
RPR_remark      DBOANEE.AGR_DISCOUNT_TYPE.remark%TYPE,
DelayInDays     number,
CA_total        number,
RFAi            number,
RFA2            number,
BOSE         number,
RMDL            number,
NPAB            number,
NRSi            number,
EDI             number,
EDIWamount      number,
EDI2            number,
EDI2amount      number,
RAPP            number,
RAPP_amount     number,
Cli1            number,
Cli1_amount     number,
CEGA            number,
SPI             number,
PGL1            number,
PGL2            number,
DATA            number,
Cli2            number,
DPSC            number,
TGSC            number,
RNP1            number,
RNP2            number,
PISC            number,
PPSC            number,
ZPSC            number,
PSSC            number,
ZPHS            number,
TGHS            number,
PSHS            number,
PPHS            number,
PIHS            number,
DPHS            number,
Sibo            number,
Code            number,
RFAc            number,
RFCC            number,
infos           dboanee.agreement.infos%TYPE
);

type tblContrWTSF2 is table of rowContrWTSF2;

function funContractWTSF2
(yr number )
return tblContrWTSF2
pipelined;
end prdContractWTSF2;
/

