create package body      prdContractWTSF3 is
function funContractWTSF3
(yr number )
return tblContrWTSF3
pipelined
is
begin

if yr is null then
for curr in
(
select
  t310.N_AGREEMENT,
  t310.VERSION,
  t040.cod_utl_supplier as supplier,
  t040. Name as supplier_name,
  ac.name as BUYER, 
  t310. Condition,
  nvl((select t356.text_Value
  from dboanee.agr_option_value t356
  where 
  t356.id_agreement = t310.id_agreement 
  and t356.id_option = 'EDRP'
  and t356.ind_active = '1'),'') 
  as code_fiscal,
  t310. SHORT_CONDITION,
  t310. ID_AGR_STATUS,
  t310.NB_FISCAL,
  t310.DT_Fiscal,
  t310.ID_AGR_TYPE,
  t310.DT_CREATION,


--RFAi
    nvl((select t350.LABEL
			from DBOANEE.AGR_EYR t350
			where 
            
            t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0' 
			and t350.id_EYR_Type = 'RFAI'
			and t350.ind_active = '1'), '') 
	as RFAi,
	
  
--RFA2
    nvl((select t350.LABEL
			from DBOANEE.AGR_EYR  t350
			where 
            t350.id_Agreement = t310.id_agreement
			and t350. ind_Conditionnal = '0' 
			and t350.id_EYR_Type = 'RFA2'
			and t350.ind_active = '1'),'') 
	as RFA2,
			

--RMDL Remodeling
    nvl((select t340.description
			from DBOANEE.AGR_SERVICE  t340
			where 
			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'RMDL'
			and t340. ind_active = '1'),'') 
	AS RMDL,


--new position
	nvl((select t340.description
			from DBOANEE.AGR_SERVICE  t340
			where 
			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'NPAB'
			and t340. ind_active = '1'), '') 
	AS New_pos,
	


--NRSi
	nvl((select t350.LABEL
			from DBOANEE.AGR_EYR  t350
			where 
			t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'NRSI'
			and t350. ind_active = '1'), '') 
	as NRSi,


--EDI
	nvl((select t350.LABEL
			from DBOANEE.AGR_EYR  t350
			where 
			t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDIW'
			and t350. ind_active = '1'), '') 
	as EDI,


--EDI2
		nvl((select t350.LABEL
			from DBOANEE.AGR_EYR   t350
			where 
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDI2'
			and t350. ind_active = '1'), '') 
		as EDI2,


--CEGA
	nvl((select t350.LABEL
			from DBOANEE.AGR_EYR   t350
			where 
			 
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CEGA'
			and t350.ind_active = '1'),'')
	as CEGA,


--SPi%
	nvl((select t350.LABEL
			from DBOANEE.AGR_EYR   t350
			where 
			
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'SPI%'
			and t350.ind_active = '1'),'') 
	as SPi,


--RAPP 
	nvl((select t350.LABEL
			from DBOANEE.AGR_EYR t350
			where 
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type  = 'RAPP'
			and t350.ind_active = '1'),'') 
	as RAPP,


--CLi1 
	nvl((select t350.LABEL
			from DBOANEE.AGR_EYR   t350
			where 
			
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI1'
			and t350. ind_active = '1'), 0) 
	as CLi1,

--DATA
    nvl((select t350.LABEL
			from DBOANEE.AGR_EYR t350
			where 
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'DATA'
			and t350.ind_active = '1'),'') 
	as DATA,


--CLi2
	nvl((select t350.LABEL
			from AGR_EYR   t350
			where 
			
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI2'
			and t350. ind_active = '1'), '') 
	as Cli2,

--Degustation
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			 
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'DPSC'
			and t340.ind_active = '1'), '') AS Degustation,

--TGSC
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'TGSC'
			and t340.ind_active = '1'), '') AS TGSC,

--PISC
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'PISC'
			and t340.ind_active = '1'), '') AS PISC,


--PPSC
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'PPSC'
			and t340.ind_active = '1'), '') AS PPSC,


--ZPSC
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			 
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'ZPSC'
			and t340.ind_active = '1'), '') AS ZPSC,



--PSSC
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'PSSC'
			and t340.ind_active = '1'), '') AS PSSC,


--SIBO
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'SIBO'
			and t340.ind_active = '1'), '') AS SIBO,


--Code
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'CODE'
			and t340.ind_active = '1'), '') AS CODE,


--RFAc_rate
    nvl((select max(t353.Rate)*100
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where  
			t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFAC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'), 0)
    as RFAc_rate, 


--RFAc_description
    nvl((select distinct t350.LABEL
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where 
			t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFAC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'),'')
    as RFAc_description, 


--RFCC_rate
    nvl((select max(t353.Rate)*100
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where 
			t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFCC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'), 0)
    as RFCc_rate, 


--RFCc_description
    nvl((select distinct t350.LABEL
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where 
			t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFCC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'),'')
    as RFCc_description, 
    

--ANNV
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'ANNV'
			and t340.ind_active = '1'), '') AS ANNV,

		Infos

	from 
	dboanee.AGREEMENT  t310 inner join
	dboanee.SUPPLIER  t040 on
	t310.id_supplier = t040. id_supplier

	left outer join dboanee.AGR_PAYMENT  t320 on
	t310.id_agreement= t320.id_agreement and t320.id_Payment_Type = 'TERM'

        join dboanee.AGR_CONDITION t315 on
        t310.id_agreement = t315.id_agreement 

        left join dboanee.negotiation_group  ng
        on t315.id_supplier=ng.id_supplier
        and substr(t315.id_negotiation_group, 1,3)=ng.id_negotiation_group

        left join dboanee.user_account ac
        on ng.id_user_account=ac.id_user_account


	
       where
       t310.id_agr_status    in ('SGN', 'CAN') 
) loop
pipe row (curr);
end loop;
else

for curr in
(
select
  t310.N_AGREEMENT,
  t310.VERSION,
  t040.cod_utl_supplier as supplier,
  t040. Name as supplier_name,
  ac.name as BUYER, 
  t310. Condition,
  nvl((select t356.text_Value
  from dboanee.agr_option_value t356
  where 
  t356.id_agreement = t310.id_agreement 
  and t356.id_option = 'EDRP'
  and t356.ind_active = '1'),'') 
  as code_fiscal,
  t310. SHORT_CONDITION,
  t310. ID_AGR_STATUS,
  t310.NB_FISCAL,
  t310.DT_Fiscal,
  t310.ID_AGR_TYPE,
  t310.DT_CREATION,


--RFAi
    nvl((select t350.LABEL
			from DBOANEE.AGR_EYR t350
			where 
            t310.Year = yr   and
            t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0' 
			and t350.id_EYR_Type = 'RFAI'
			and t350.ind_active = '1'), '') 
	as RFAi,
	
  
--RFA2
    nvl((select t350.LABEL
			from DBOANEE.AGR_EYR  t350
			where t310.Year = yr   and
            t350.id_Agreement = t310.id_agreement
			and t350. ind_Conditionnal = '0' 
			and t350.id_EYR_Type = 'RFA2'
			and t350.ind_active = '1'),'') 
	as RFA2,
			

--RMDL Remodeling
    nvl((select t340.description
			from DBOANEE.AGR_SERVICE  t340
			where t310.Year = yr   and
			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'RMDL'
			and t340. ind_active = '1'),'') 
	AS RMDL,


--new position
	nvl((select t340.description
			from DBOANEE.AGR_SERVICE  t340
			where t310.Year = yr   and
			t340.id_agreement = t310.id_agreement
			and t340. id_Service_Type = 'NPAB'
			and t340. ind_active = '1'), '') 
	AS New_pos,
	


--NRSi
	nvl((select t350.LABEL
			from DBOANEE.AGR_EYR  t350
			where t310.Year = yr   and
			t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'NRSI'
			and t350. ind_active = '1'), '') 
	as NRSi,


--EDI
	nvl((select t350.LABEL
			from DBOANEE.AGR_EYR  t350
			where t310.Year = yr   and
			t350.id_Agreement = t310.id_agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDIW'
			and t350. ind_active = '1'), '') 
	as EDI,


--EDI2
		nvl((select t350.LABEL
			from DBOANEE.AGR_EYR   t350
			where 
			t310.Year = yr   and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'EDI2'
			and t350. ind_active = '1'), '') 
		as EDI2,


--CEGA
	nvl((select t350.LABEL
			from DBOANEE.AGR_EYR   t350
			where 
			 t310.Year = yr   and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CEGA'
			and t350.ind_active = '1'),'')
	as CEGA,


--SPi%
	nvl((select t350.LABEL
			from DBOANEE.AGR_EYR   t350
			where 
			 t310.Year = yr   and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'SPI%'
			and t350.ind_active = '1'),'') 
	as SPi,


--RAPP 
	nvl((select t350.LABEL
			from DBOANEE.AGR_EYR t350
			where t310.Year = yr   and
            t350.id_Agreement = t310. id_Agreement
      	    and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type  = 'RAPP'
			and t350.ind_active = '1'),'') 
	as RAPP,


--CLi1 
	nvl((select t350.LABEL
			from DBOANEE.AGR_EYR   t350
			where 
			 t310.Year = yr   and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI1'
			and t350. ind_active = '1'), 0) 
	as CLi1,

--DATA
    nvl((select t350.LABEL
			from DBOANEE.AGR_EYR t350
			where t310.Year = yr   and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'DATA'
			and t350.ind_active = '1'),'') 
	as DATA,


--CLi2
	nvl((select t350.LABEL
			from AGR_EYR   t350
			where 
			t310.Year = yr   and
			t350. id_Agreement = t310. id_Agreement
			and t350.ind_Conditionnal = '0'
			and t350. id_EYR_Type = 'CLI2'
			and t350. ind_active = '1'), '') 
	as Cli2,

--Degustation
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			 t310.Year = yr   and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'DPSC'
			and t340.ind_active = '1'), '') AS Degustation,

--TGSC
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			 t310.Year = yr   and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'TGSC'
			and t340.ind_active = '1'), '') AS TGSC,

--PISC
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			 t310.Year = yr   and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'PISC'
			and t340.ind_active = '1'), '') AS PISC,


--PPSC
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			 t310.Year = yr   and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'PPSC'
			and t340.ind_active = '1'), '') AS PPSC,


--ZPSC
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			 t310.Year = yr   and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'ZPSC'
			and t340.ind_active = '1'), '') AS ZPSC,



--PSSC
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			 t310.Year = yr   and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'PSSC'
			and t340.ind_active = '1'), '') AS PSSC,


--SIBO
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			 t310.Year = yr   and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'SIBO'
			and t340.ind_active = '1'), '') AS SIBO,


--Code
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			 t310.Year = yr   and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'CODE'
			and t340.ind_active = '1'), '') AS CODE,


--RFAc_rate
    nvl((select max(t353.Rate)*100
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where t310.Year = yr   
			and t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFAC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'), 0)
    as RFAc_rate, 


--RFAc_description
    nvl((select distinct t350.LABEL
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where t310.Year = yr   
			and t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFAC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'),'')
    as RFAc_description, 


--RFCC_rate
    nvl((select max(t353.Rate)*100
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where t310.Year = yr   
			and t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFCC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'), 0)
    as RFCc_rate, 


--RFCc_description
    nvl((select distinct t350.LABEL
			from AGR_EYR t350 join  AGR_EYR_LEVEL t353
            on  t350.id_agr_eyr=t353.id_agr_eyr
			where t310.Year = yr   
			and t350.Id_agreement = t310.id_agreement
			and t350.Id_eyr_type = 'RFCC'
			and t353.ind_active = '1'
			and t350.ind_active = '1'),'')
    as RFCc_description, 
    

--ANNV
		nvl((select t340.description
			from AGR_SERVICE   t340
			where
			 t310.Year = yr   and
			t340. id_Agreement = t310. id_Agreement
			and t340.id_Service_Type = 'ANNV'
			and t340.ind_active = '1'), '') AS ANNV,

		Infos

	from 
	dboanee.AGREEMENT  t310 inner join
	dboanee.SUPPLIER  t040 on
	t310.id_supplier = t040. id_supplier

	left outer join dboanee.AGR_PAYMENT  t320 on
	t310.id_agreement= t320.id_agreement and t320.id_Payment_Type = 'TERM'

        join dboanee.AGR_CONDITION t315 on
        t310.id_agreement = t315.id_agreement 

        left join dboanee.negotiation_group  ng
        on t315.id_supplier=ng.id_supplier
        and substr(t315.id_negotiation_group, 1,3)=ng.id_negotiation_group

        left join dboanee.user_account ac
        on ng.id_user_account=ac.id_user_account


	
       where
       t310.year = yr   
       and t310.id_agr_status    in ('SGN', 'CAN')


) loop
pipe row (curr);
end loop;
end if;
end funContractWTSF3;
end prdContractWTSF3;
/

