create type        SYS_PLSQL_173536_DUMMY_1 as table of number;
/

