create package      prdContractWTSFSegm2  is

type rowContractWTSFSegm2 is record(

N_AGREEMENT     dboanee.agreement.N_AGREEMENT%TYPE,
VERSION         dboanee.agreement.VERSION%TYPE,
supplier        dboanee.supplier.cod_utl_supplier%TYPE,
supplier_name   dboanee.supplier.name%TYPE,
id_negotiation_group  dboanee.AGR_CONDITION.id_negotiation_group%TYPE,
Condition       dboanee.agreement.Condition%TYPE,
code_fiscal     dboanee.AGR_OPTION_VALUE.text_value%TYPE,
SHORT_CONDITION dboanee.agreement.SHORT_CONDITION%TYPE,
ID_AGR_STATUS   dboanee.agreement.ID_AGR_STATUS%TYPE,
ID_AGR_TYPE     dboanee.agreement.ID_AGR_TYPE%TYPE,
NB_FISCAL       dboanee.agreement.NB_FISCAL%TYPE,
DT_Fiscal       dboanee.agreement.DT_Fiscal%TYPE ,
NB_SERVICE      dboanee.agreement.NB_SERVICE%TYPE,
DT_SERVICE      dboanee.agreement.DT_SERVICE%TYPE ,
buyer           dboanee.user_account.name%TYPE,
DT_CREATION     dboanee.agreement.DT_CREATION%TYPE,
Rba             number,
Rpr             number,
DelayInDays     number,
CA_total        number,
RFAi            number,
RFA2            number,
BOSE            number,
RMDL            number,
BORE            number,
NPAB            number,
NRSi            number,
EDIW            number,
EDIWamount      number,
EDI2            number,
EDI2amount      number,
RAPP            number,
RAPPamount      number,
Cli1            number,
Cli1amount      number,
CEGA            number,
SPI            number,
PGL1            number,
PGL2            number,
RFCC            number,
"DATA"            number,
Cli2            number,
DPSC            number,
TGsc            number,
PISC            number,
PPSC            number,
ZPSC            number,
PSSC            number,
ZPHS      number,
TGHS      number,
PSHS      number,
PPHS     number,
PIHS      number,
DPHS      number,
Sibo            number,
Code            number,
RFAc            number,
infos           dboanee.agreement.infos%TYPE
);

type tblContractWTSFSegm2 is table of rowContractWTSFSegm2;

function funContractWTSFSegm2
(yr number )
return tblContractWTSFSegm2
pipelined;
end prdContractWTSFSegm2;
/

