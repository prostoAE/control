create type        SYS_PLSQL_29748_DUMMY_1 as table of number;
/

