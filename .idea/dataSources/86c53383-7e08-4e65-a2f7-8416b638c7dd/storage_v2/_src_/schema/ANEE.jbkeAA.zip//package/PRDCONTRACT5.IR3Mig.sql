create package      prdContract5  is

type rowContract5 is record(

N_AGREEMENT     dboanee.agreement.N_AGREEMENT%TYPE,
VERSION         dboanee.agreement.VERSION%TYPE,
supplier        dboanee.supplier.cod_utl_supplier%TYPE,
supplier_name   dboanee.supplier.name%TYPE,
buyer           dboanee.user_account.name%TYPE,
Condition       dboanee.agreement.Condition%TYPE,
code_fiscal     dboanee.AGR_OPTION_VALUE.text_value%TYPE,
SHORT_CONDITION dboanee.agreement.SHORT_CONDITION%TYPE,
ID_AGR_STATUS   dboanee.agreement.ID_AGR_STATUS%TYPE,
ID_AGR_TYPE     dboanee.agreement.ID_AGR_TYPE%TYPE,
NB_FISCAL       dboanee.agreement.NB_FISCAL%TYPE,
DT_Fiscal       dboanee.agreement.DT_Fiscal%TYPE ,
NB_SERVICE      dboanee.agreement.NB_SERVICE%TYPE,
DT_SERVICE      dboanee.agreement.DT_SERVICE%TYPE ,
DT_CREATION     dboanee.agreement.DT_CREATION%TYPE,
Rba             number,
Rpr             number,
DelayInDays     number,
CA_total        number,
RFAi            number,
RFA2            number,
BOSE         number,
New_pos         number,
NRSi            number,
EDI             number,
EDIWamount      number,
EDI2            number,
EDI2amount      number,
Cli1            number,
Cli1_amount     number,
CEGA            number,
RAPP            number,
RAPP_amount     number,
DATA            number,
Cli2            number,
Degustation     number,
TGsc            number,
PISC            number,
PPSC            number,
ZPSC            number,
ZPHS_Cost1      number,
TGHS_Cost1      number,
PSHS_Cost1      number,
PPHS_Cost1      number,
PIHS_Cost1      number,
DPHS_Cost1      number,
PSSC            number,
Sibo            number,
Code            number,
RFAc           number,
RMDL           number,
SPi           number,
PGL1           number,
PGL2           number,
RFCC           number,
MRKD            number,
BOSF            number,
SITC            number,
NPSF            number,
DPSF            number,
PISF            number,
PPSF            number,
PSSF            number,
ANN2            number,
TGSF            number,
ZPSF            number,
NPEF            number,
ANNV            number,
infos          dboanee.agreement.infos%TYPE
);

type tblContract5 is table of rowContract5;

function funContract5
(yr number )
return tblContract5
pipelined;
end prdContract5;
/

