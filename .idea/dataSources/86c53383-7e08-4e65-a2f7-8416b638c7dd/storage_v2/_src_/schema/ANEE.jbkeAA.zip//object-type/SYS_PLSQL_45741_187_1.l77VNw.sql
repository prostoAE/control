create type        SYS_PLSQL_45741_187_1 as table of "ANEE"."SYS_PLSQL_45741_9_1";
/

