create package      prdContractWTSF3  is

type rowContrWTSF3 is record(
N_AGREEMENT     dboanee.agreement.N_AGREEMENT%TYPE, 
VERSION         dboanee.agreement.VERSION%TYPE,
supplier        dboanee.supplier.cod_utl_supplier%TYPE,
supplier_name   dboanee.supplier.name%TYPE,
buyer           dboanee.user_account.name%TYPE,
Condition       dboanee.agreement.Condition%TYPE,
code_fiscal     dboanee.AGR_OPTION_VALUE.text_value%TYPE,
SHORT_CONDITION dboanee.agreement.SHORT_CONDITION%TYPE,
ID_AGR_STATUS   dboanee.agreement.ID_AGR_STATUS%TYPE,
NB_FISCAL       dboanee.agreement.NB_FISCAL%TYPE,
DT_Fiscal       dboanee.agreement.DT_Fiscal%TYPE , 
ID_AGR_TYPE     dboanee.agreement.ID_AGR_TYPE%TYPE,
DT_CREATION     dboanee.agreement.DT_CREATION%TYPE , 
RFAi            DBOANEE.AGR_EYR.LABEL%TYPE,
RFA2            DBOANEE.AGR_EYR.LABEL%TYPE,
RMDL            DBOANEE.AGR_SERVICE.description%TYPE,
New_pos         DBOANEE.AGR_SERVICE.description%TYPE,
NRSi            DBOANEE.AGR_EYR.LABEL%TYPE,
EDI             DBOANEE.AGR_EYR.LABEL%TYPE,
EDI2            DBOANEE.AGR_EYR.LABEL%TYPE,
CEGA            DBOANEE.AGR_EYR.LABEL%TYPE,
SPI             DBOANEE.AGR_EYR.LABEL%TYPE,
RAPP            DBOANEE.AGR_EYR.LABEL%TYPE,
Cli1            DBOANEE.AGR_EYR.LABEL%TYPE,
DATA            DBOANEE.AGR_EYR.LABEL%TYPE,
Cli2            DBOANEE.AGR_EYR.LABEL%TYPE,
Degustation     DBOANEE.AGR_SERVICE.description%TYPE,
TGSC            DBOANEE.AGR_SERVICE.description%TYPE,
PISC            DBOANEE.AGR_SERVICE.description%TYPE,
PPSC            DBOANEE.AGR_SERVICE.description%TYPE,
ZPSC            DBOANEE.AGR_SERVICE.description%TYPE,
PSSC            DBOANEE.AGR_SERVICE.description%TYPE,
SIBO            DBOANEE.AGR_SERVICE.description%TYPE,
CODE            DBOANEE.AGR_SERVICE.description%TYPE,
RFAc_rate       number,
RFAC_description   DBOANEE.AGR_EYR.LABEL%TYPE,
RFCc_rate       number,
RFCC_description   DBOANEE.AGR_EYR.LABEL%TYPE,
ANNV           DBOANEE.AGR_SERVICE.description%TYPE,
infos                   dboanee.agreement.infos%TYPE
); 

type tblContrWTSF3 is table of rowContrWTSF3; 

function funContractWTSF3
(yr number )
return tblContrWTSF3
pipelined; 
end prdContractWTSF3;
/

